package gui.Profe;

import gui.Inicio.FormularioInicio;
import gui.PanelManager;
import Controlador.Profesor;
import javax.swing.*;
import java.awt.*;

// Formulario de inicio para el profesor que permite navegar en tareas de profesor y cerrar sesión
public class ProfesorPanel extends JPanel {
    private PanelManager panel;
    private Profesor profesor;

    public ProfesorPanel(PanelManager panel, Profesor profesor) {
        this.panel = panel;
        this.profesor = profesor;
        setLayout(new BorderLayout(10, 10));
        armarFormulario();
    }

    private void armarFormulario() {
        // Panel Principal
        JPanel panelPrincipal = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Botones de acciones
        JButton btnCalificaciones = new JButton("Gestionar Calificaciones");
        JButton btnSalir = new JButton("Cerrar Sesión");

        // Layout
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panelPrincipal.add(new JLabel("Bienvenido, Profesor " + profesor.getNombre()), gbc);

        gbc.gridy = 1; gbc.gridwidth = 1;
        panelPrincipal.add(btnCalificaciones, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        panelPrincipal.add(btnSalir, gbc);

        add(panelPrincipal, BorderLayout.CENTER);

        // Eventos
        btnCalificaciones.addActionListener(e ->
                panel.mostrar(new FormularioCalificaciones(panel, profesor)));

        btnSalir.addActionListener(e ->
                panel.mostrar(new FormularioInicio(panel)));
    }
}
