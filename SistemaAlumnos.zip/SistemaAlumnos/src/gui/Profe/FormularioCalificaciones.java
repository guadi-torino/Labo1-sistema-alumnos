package gui.Profe;

import Controlador.Alumno;
import Controlador.Curso;
import Controlador.Profesor;
import gui.Alumno.AlumnoPanel;
import gui.PanelManager;
import service.AlumnoService;
import service.CursoService;
import service.ProfesorService;
import service.ServiceException;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

// Formulario para que el profesor pueda asignar calificaciones a los alumnos de un curso.
public class FormularioCalificaciones extends JPanel {
    private PanelManager panel;
    private Profesor profesor;
    private CursoService cursoService;
    private ProfesorService profesorService;
    private AlumnoService alumnoService;

    private JComboBox<Curso> comboCursos;
    private JTable tablaAlumnos;
    private DefaultTableModel tableModel;
    private JButton btnGuardar;
    private JButton btnAtras;

    public FormularioCalificaciones(PanelManager panel, Profesor profesor) {
        this.panel = panel;
        this.profesor = profesor;
        this.cursoService = new CursoService();
        this.profesorService = new ProfesorService();
        this.alumnoService = new AlumnoService();

        setLayout(new BorderLayout(10, 10));
        armarFormulario();
    }

    private void armarFormulario() {
        // Panel superior: selección del curso
        JPanel panelTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelTop.add(new JLabel("Curso:"));
        comboCursos = new JComboBox<>();
        panelTop.add(comboCursos);

        // Centro: tabla con los alumnos y la celda editable para la calificación final
        tableModel = new DefaultTableModel(new Object[]{"Alumno", "Calificación Final"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Solo la columna "Calificación Final" (índice 1) es editable
                return column == 1;
            }
        };
        tablaAlumnos = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(tablaAlumnos);

        // Panel inferior: botón guardar
        JPanel panelBottom = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnGuardar = new JButton("Guardar Calificaciones");
        panelBottom.add(btnGuardar);

        // Panel principal
        JPanel panelPrincipal = new JPanel(new BorderLayout(10, 10));
        panelPrincipal.add(panelTop, BorderLayout.NORTH);
        panelPrincipal.add(scrollPane, BorderLayout.CENTER);
        panelPrincipal.add(panelBottom, BorderLayout.SOUTH);

        add(panelPrincipal, BorderLayout.CENTER);

        // Cargar cursos
        cargarCursos();

        // Al cambiar el curso se carga la lista de alumnos en la tabla
        comboCursos.addActionListener(e -> cargarAlumnosEnTabla());

        // Al presionar guardar, se procesan las calificaciones
        btnGuardar.addActionListener(e -> guardarCalificaciones());

        // Configurar el botón "Atrás" para volver al formulario de búsqueda de alumnos.
        btnAtras = new JButton("Atrás");
        btnAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new ProfesorPanel(panel,profesor));
            }
        });

        // Agregar el botón en la parte inferior
        JPanel panelBoton = new JPanel();
        panelBoton.add(btnAtras);
        add(panelBoton, BorderLayout.SOUTH);

    }

    private void cargarCursos() {
        try {
            List<Curso> cursos = cursoService.buscarTodos();
            comboCursos.removeAllItems();
            for (Curso curso : cursos) {
                comboCursos.addItem(curso);
            }
            // Opcional: si hay al menos un curso, cargar sus alumnos de inmediato
            if (comboCursos.getItemCount() > 0) {
                comboCursos.setSelectedIndex(0);
                cargarAlumnosEnTabla();
            }
        } catch (ServiceException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar cursos: " + e.getMessage());
        }
    }

    private void cargarAlumnosEnTabla() {
        tableModel.setRowCount(0);
        Curso curso = (Curso) comboCursos.getSelectedItem();
        if (curso == null) {
            return;
        }
        try {
            // Supongamos que agregaste el método en tu CursoService o AlumnoService:
            List<Alumno> alumnos = alumnoService.obtenerAlumnosPorCurso(curso.getId());
            if (alumnos == null || alumnos.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No hay alumnos inscritos en el curso seleccionado.");
            }
            for (Alumno alumno : alumnos) {
                tableModel.addRow(new Object[]{alumno, ""});
            }
        } catch (ServiceException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar alumnos: " + e.getMessage());
        }
    }

    private void guardarCalificaciones() {
        Curso curso = (Curso) comboCursos.getSelectedItem();
        if (curso == null) {
            JOptionPane.showMessageDialog(this, "Seleccione un curso.");
            return;
        }

        int profesorId = profesor.getId();
        int cursoId = curso.getId();
        StringBuilder errores = new StringBuilder();

        try {
            // Recorremos cada fila de la tabla
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                Alumno alumno = (Alumno) tableModel.getValueAt(i, 0);
                Object notaObj = tableModel.getValueAt(i, 1);

                // Valida que se haya ingresado la nota
                if (notaObj == null || notaObj.toString().trim().isEmpty()) {
                    errores.append("No se ingresó calificación para el alumno ").append(alumno).append("\n");
                    continue;
                }

                double notaFinal;
                try {
                    notaFinal = Double.parseDouble(notaObj.toString().trim());
                } catch (NumberFormatException ex) {
                    errores.append("La calificación para el alumno ").append(alumno)
                            .append(" no es un número válido.\n");
                    continue;
                }
                if (notaFinal < 1 || notaFinal > 10) {
                    errores.append("La calificación para el alumno ").append(alumno)
                            .append(" debe estar entre 1 y 10.\n");
                    continue;
                }
                // Llama al método para asignar la calificación final
                profesorService.asignarCalificacionFinal(profesorId, alumno.getId(), cursoId, notaFinal);
            }
            if (errores.length() > 0) {
                // Si se acumularon errores, se muestran al usuario
                JOptionPane.showMessageDialog(this, "Errores encontrados:\n" + errores.toString());
            } else {
                JOptionPane.showMessageDialog(this, "Calificaciones guardadas correctamente.");
            }
        } catch (ServiceException ex) {
            JOptionPane.showMessageDialog(this, "Error al guardar las calificaciones: " + ex.getMessage());
        }
    }
}
