package gui.AdminProfesor;

import Controlador.Profesor;
import gui.PanelManager;
import service.ProfesorService;
import service.ServiceException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

// Formulario para buscar un profesor por ID o mostrar todos los profesores
public class FormularioProfesorBuscar extends JPanel {
    // Paneles internos para la búsqueda y el botón "Atras"
    private JPanel panelBuscar;
    private JPanel panelAtras;

    private PanelManager panel;
    private ProfesorService profesorService; // Servicio para operaciones sobre Profesor

    private JLabel idLabel;
    private JTextField idText;
    private JButton botonBuscar;
    private JButton botonAtras;
    private JButton botonBuscarTodos;

    public FormularioProfesorBuscar(PanelManager panel) {
        this.panel = panel;
        profesorService = new ProfesorService();
        setLayout(new GridBagLayout());
        armarFormulario();
    }

    private void armarFormulario() {
        panelBuscar = new JPanel();
        panelAtras = new JPanel();
        panelAtras.setLayout(new GridBagLayout());
        // Se define un layout en forma de grilla para los componentes de búsqueda
        panelBuscar.setLayout(new GridLayout(3, 1, 10, 10));

        // Cambiar textos para trabajar con Profesor
        idLabel = new JLabel("Ingrese ID del Profesor:");
        idText = new JTextField(7);
        botonBuscar = new JButton("Buscar");
        botonBuscarTodos = new JButton("Buscar Todos");
        botonAtras = new JButton("<-");

        // Se agregan los componentes al panel de búsqueda con GridBagConstraints
        GridBagConstraints gbcLabel = new GridBagConstraints();
        gbcLabel.gridx = 0;
        gbcLabel.gridy = 0;
        gbcLabel.weightx = 1;
        gbcLabel.weighty = 1;
        gbcLabel.fill = GridBagConstraints.NONE;
        panelBuscar.add(idLabel, gbcLabel);

        GridBagConstraints gbcTxt = new GridBagConstraints();
        gbcTxt.gridx = 1;
        gbcTxt.gridy = 0;
        gbcTxt.weightx = 1;
        gbcTxt.weighty = 1;
        gbcTxt.fill = GridBagConstraints.NONE;
        panelBuscar.add(idText, gbcTxt);

        GridBagConstraints gbcBotonBuscar = new GridBagConstraints();
        gbcBotonBuscar.gridx = 1;
        gbcBotonBuscar.gridy = 1;
        gbcBotonBuscar.weightx = 2;
        gbcBotonBuscar.weighty = 2;
        gbcBotonBuscar.fill = GridBagConstraints.NONE;
        panelBuscar.add(botonBuscar, gbcBotonBuscar);

        GridBagConstraints gbcBotonBuscarTodos = new GridBagConstraints();
        gbcBotonBuscarTodos.gridx = 1;
        gbcBotonBuscarTodos.gridy = 2;
        gbcBotonBuscarTodos.weightx = 2;
        gbcBotonBuscarTodos.weighty = 2;
        gbcBotonBuscarTodos.fill = GridBagConstraints.NONE;
        panelBuscar.add(botonBuscarTodos, gbcBotonBuscarTodos);

        // Se ubica el panel de búsqueda en el panel principal
        GridBagConstraints gbcBuscar = new GridBagConstraints();
        gbcBuscar.gridx = 0;
        gbcBuscar.gridy = 1;
        gbcBuscar.weightx = 1;
        gbcBuscar.weighty = 1;
        gbcBuscar.fill = GridBagConstraints.NONE;
        add(panelBuscar, gbcBuscar);

        // Se ubica el botón "Atras" en la parte superior izquierda
        GridBagConstraints gbcAtras = new GridBagConstraints();
        gbcAtras.gridx = 0;
        gbcAtras.gridy = 0;
        gbcAtras.anchor = GridBagConstraints.NORTHWEST;
        add(botonAtras, gbcAtras);

        // Acción para buscar un profesor por ID
        botonBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idStr = idText.getText().trim();
                if (idStr.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "El campo de ID no puede estar vacío");
                } else if (!idStr.matches("[0-9]+")) {
                    JOptionPane.showMessageDialog(null, "El ID solo puede contener números");
                } else {
                    try {
                        int id = Integer.parseInt(idStr);
                        Profesor profesor = profesorService.buscar(id);
                        if (profesor == null) {
                            JOptionPane.showMessageDialog(null, "No se encontró el profesor solicitado");
                        } else {
                            // Se muestra el formulario que presenta los datos del profesor encontrado
                            panel.mostrar(new FormularioProfesorEncontrado(panel, profesor));
                        }
                    } catch (ServiceException ex) {
                        JOptionPane.showMessageDialog(null, ex.getMessage());
                    }
                }
            }
        });

        // Acción para buscar y mostrar todos los profesores
        botonBuscarTodos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    ArrayList<Profesor> profesores = profesorService.buscarTodos();
                    panel.mostrar(new FormularioListadoProfesor(panel, profesores));
                } catch (ServiceException ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });

        // Acción para volver al formulario anterior
        botonAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new FormularioCrearProfesor(panel));
            }
        });
    }
}
