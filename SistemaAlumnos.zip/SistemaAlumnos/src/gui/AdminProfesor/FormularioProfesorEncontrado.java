package gui.AdminProfesor;

import Controlador.Profesor;
import gui.PanelManager;
import service.ProfesorService;
import service.ServiceException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Formulario para mostrar la información de un profesor encontrado
public class FormularioProfesorEncontrado extends JPanel {
    // Paneles para organizar la información y los botones
    private JPanel panelDatos;
    private JPanel panelBotones;
    private JPanel panelAtras;

    // Etiquetas para mostrar la información del profesor
    private JLabel labelId;
    private JLabel labelNombre;
    private JLabel labelEmail;

    // Referencia al PanelManager para gestionar el cambio de formularios
    private PanelManager panel;
    // Instancia del servicio de profesores
    private ProfesorService profesorService;

    // Botones para acciones
    private JButton botonModificar;
    private JButton botonEliminar;
    private JButton botonAtras;

    public FormularioProfesorEncontrado(PanelManager panel, Profesor profesor) {
        this.panel = panel;
        profesorService = new ProfesorService();
        setLayout(new GridBagLayout());
        armarFormulario(profesor);
    }

    private void armarFormulario(Profesor profesor) {
        // Inicialización de paneles
        panelDatos = new JPanel(new GridLayout(3, 1, 5, 5));
        panelBotones = new JPanel(new GridLayout(1, 2, 10, 10));
        panelAtras = new JPanel(new FlowLayout(FlowLayout.LEFT));

        // Creación de etiquetas con los datos del profesor
        labelId = new JLabel("ID: " + profesor.getId());
        labelNombre = new JLabel("Nombre: " + profesor.getNombre());
        labelEmail = new JLabel("Email: " + profesor.getEmail());

        // Agregar etiquetas al panel de datos
        panelDatos.add(labelId);
        panelDatos.add(labelNombre);
        panelDatos.add(labelEmail);

        // Creación de botones de acción
        botonModificar = new JButton("Modificar");
        botonEliminar = new JButton("Eliminar");
        panelBotones.add(botonModificar);
        panelBotones.add(botonEliminar);

        botonAtras = new JButton("<-");
        panelAtras.add(botonAtras);

        // Acción para el botón "Atrás": regresa al formulario de búsqueda de profesores
        botonAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new FormularioProfesorBuscar(panel));
            }
        });

        // Acción para modificar el profesor (se asume la existencia de FormularioProfesorModificar)
        botonModificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new FormularioProfesorModificar(panel, profesor));
            }
        });

        // Acción para eliminar el profesor
        botonEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(
                        null,
                        "¿Está seguro de eliminar el profesor?",
                        "Eliminar Profesor",
                        JOptionPane.YES_NO_OPTION
                );
                if (respuesta == JOptionPane.YES_OPTION) {
                    try {
                        profesorService.eliminarProfesor(profesor.getId());
                        JOptionPane.showMessageDialog(null, "Profesor eliminado correctamente");
                        panel.mostrar(new FormularioProfesorBuscar(panel));
                    } catch (ServiceException ex) {
                        JOptionPane.showMessageDialog(null, "No se pudo eliminar el profesor: " + ex.getMessage());
                    }
                }
            }
        });

        // Uso de GridBagConstraints para la disposición de los paneles
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Panel de "Atrás"
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        add(panelAtras, gbc);

        // Panel con los datos del profesor
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(panelDatos, gbc);

        // Panel con los botones (Modificar y Eliminar)
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(panelBotones, gbc);
    }
}
