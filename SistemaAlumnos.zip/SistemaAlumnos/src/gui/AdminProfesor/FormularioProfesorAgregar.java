package gui.AdminProfesor;

import Controlador.Profesor;
import gui.PanelManager;
import service.ProfesorService;
import service.ServiceException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Formulario para agregar un profesor.
public class FormularioProfesorAgregar extends JPanel {
     private PanelManager panel; // Se asume que existe una clase PanelManager para gestionar los paneles
     private JButton botonAtras;

     private JLabel idLabel;
     private JTextField idField;

     private JLabel nombreLabel;
     private JTextField nombreField;

     private JLabel emailLabel;
     private JTextField emailField;

     private JButton botonAgregar;

     private ProfesorService profesorService;

     public FormularioProfesorAgregar(PanelManager panel) {
         this.panel = panel;
         profesorService = new ProfesorService();
         setLayout(new GridBagLayout());
         armarFormulario();
     }

     private void armarFormulario() {
         // Panel para los campos del formulario
         JPanel panelAgregar = new JPanel();
         panelAgregar.setLayout(new GridLayout(4, 2, 10, 10));

         // Panel para el botón "Atras"
         JPanel panelSec = new JPanel();
         panelSec.setLayout(new BorderLayout());
         panelSec.setPreferredSize(new Dimension(50, 25));

         botonAtras = new JButton("<-");
         botonAtras.setPreferredSize(new Dimension(50, 25));
         // Acción para volver al panel anterior (modifica según la navegación de tu aplicación)
         botonAtras.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent e) {
                 // Se asume que existe un formulario o panel previo para la gestión de profesores
                 panel.mostrar(new FormularioCrearProfesor(panel));
             }
         });
         panelSec.add(botonAtras, BorderLayout.WEST);

         // Campos del formulario
         idLabel = new JLabel("ID del Profesor:");
         idField = new JTextField(10);

         nombreLabel = new JLabel("Nombre del Profesor:");
         nombreField = new JTextField(10);

         emailLabel = new JLabel("Email del Profesor:");
         emailField = new JTextField(10);

         // Botón para agregar el profesor
         botonAgregar = new JButton("Agregar Profesor");
         botonAgregar.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent e) {
                 String idText = idField.getText().trim();
                 String nombre = nombreField.getText().trim();
                 String email = emailField.getText().trim();

                 // Validaciones básicas
                 if (idText.isEmpty() || nombre.isEmpty() || email.isEmpty()) {
                     JOptionPane.showMessageDialog(null, "Todos los campos deben estar llenos");
                 } else if (!idText.matches("[0-9]+")) {
                     JOptionPane.showMessageDialog(null, "El ID debe ser un número entero.");
                 } else if (!nombre.matches("[a-zA-Z\\s]+")) {
                     JOptionPane.showMessageDialog(null, "El nombre solo puede contener letras");
                 } else if (!email.matches("^(.+)@(.+)$")) {
                     JOptionPane.showMessageDialog(null, "El email no tiene un formato correcto.");
                 } else {
                     int id = Integer.parseInt(idText);
                     Profesor profesor = new Profesor(id, nombre, email);

                     try {
                         profesorService.guardarProfesor(profesor);
                         JOptionPane.showMessageDialog(null, "Profesor agregado exitosamente");

                         // Limpiar los campos luego de guardar
                         idField.setText("");
                         nombreField.setText("");
                         emailField.setText("");
                     } catch (ServiceException ex) {
                         JOptionPane.showMessageDialog(null, "Error al agregar el profesor: " + ex.getMessage());
                     }
                 }
             }
         });

         // Agregar los componentes al panel del formulario
         panelAgregar.add(idLabel);
         panelAgregar.add(idField);
         panelAgregar.add(nombreLabel);
         panelAgregar.add(nombreField);
         panelAgregar.add(emailLabel);
         panelAgregar.add(emailField);
         // Se agrega el botón en la última celda (puedes ajustar el diseño según lo necesites)
         panelAgregar.add(botonAgregar);

         // Ubicación de los paneles en el FormularioProfesorAgregar usando GridBagLayout
         GridBagConstraints gbc = new GridBagConstraints();
         gbc.gridx = 1;
         gbc.gridy = 1;
         gbc.weightx = 1;
         gbc.weighty = 1;
         gbc.fill = GridBagConstraints.NONE;
         add(panelAgregar, gbc);

         GridBagConstraints gbcSec = new GridBagConstraints();
         gbcSec.gridx = 0;
         gbcSec.gridy = 0;
         gbcSec.weightx = 0;
         gbcSec.weighty = 0;
         gbcSec.fill = GridBagConstraints.NONE;
         add(panelSec, gbcSec);
     }
}
