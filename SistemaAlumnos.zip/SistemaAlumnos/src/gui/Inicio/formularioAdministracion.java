package gui.Inicio;
import gui.AdminAlumno.FormularioAltaAlumno;
import gui.AdminCurso.FormularioCrearCurso;
import gui.FormularioReportes;
import gui.PanelManager;
import gui.AdminProfesor.FormularioCrearProfesor;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Formulario administracion muestra las opciones para crear un curso, un profesor, dar de alta un alumno y ver reportes
public class formularioAdministracion extends JPanel {
    PanelManager panel;
    JPanel panelInicio;
    JPanel panelAtras;
    JButton botonCrearCurso;
    JButton botonCrearProfesor;
    JButton botonAltaAlumno;
    JButton btnReportes;
    JButton botonAtras;


    public formularioAdministracion(PanelManager panel) {
        this.panel = panel;
        setLayout(new GridBagLayout());
        armarFormulario();
    }

    public void armarFormulario() {
        panelInicio = new JPanel();
        panelAtras = new JPanel();
        panelAtras.setLayout(new GridBagLayout());
        panelInicio.setLayout(new GridLayout(2, 2, 10, 10));
        botonCrearCurso = new JButton("Crear Curso");
        botonCrearProfesor = new JButton("Crear Profesor");
        botonAltaAlumno = new JButton("Alta Alumno");
        btnReportes = new JButton("Reportes");
        botonAtras = new JButton("<-");

        panelInicio.add(botonCrearCurso);
        panelInicio.add(botonCrearProfesor);
        panelInicio.add(botonAltaAlumno);
        panelInicio.add(btnReportes);
        panelAtras.add(botonAtras);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        add(panelAtras, gbc);
        add(panelInicio);

        GridBagConstraints gbcBotones = new GridBagConstraints();
        gbcBotones.gridx = 0;
        gbcBotones.gridy = 0;
        gbcBotones.weightx = 1;
        gbcBotones.weighty = 1;
        gbcBotones.fill = GridBagConstraints.NONE;
        add(panelInicio, gbcBotones);


        botonCrearCurso.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new FormularioCrearCurso(panel));
                panel.setJFrameTitle("Crear Curso");
            }
        });

        botonCrearProfesor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new FormularioCrearProfesor(panel));
                panel.setJFrameTitle("Crear Profesor");
            }
        });

        botonAltaAlumno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new FormularioAltaAlumno(panel));
                panel.setJFrameTitle("Alta alumno");
            }
        });

        btnReportes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new FormularioReportes(panel));
                panel.setBounds(600, 600);
                panel.setJFrameTitle("Reportes");
            }
        });

        botonAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new FormularioInicio(panel));
                panel.setJFrameTitle("Inicio");
            }
        });


    }
}