package gui.Inicio;

import gui.PanelManager;
import gui.Profe.ProfesorPanel;
import service.ProfesorService;
import javax.swing.*;
import java.awt.*;

// Formulario de inicio para el profesor que permite buscar un profesor por su ID para iniciar sesión
public class ProfesorInicio extends JPanel {
    private PanelManager panel;
    private ProfesorService profesorService;

    private JPanel panelPrincipal;
    private JPanel panelBotones;
    private JTextField txtIdProfesor;
    private JButton btnBuscar;
    private JButton btnAtras;

    public ProfesorInicio(PanelManager panel) {
        this.panel = panel;
        this.profesorService = new ProfesorService();
        setLayout(new BorderLayout(10, 10));
        armarFormulario();
    }

    private void armarFormulario() {
        // Panel Principal
        panelPrincipal = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Componentes
        JLabel lblId = new JLabel("ID Profesor:");
        txtIdProfesor = new JTextField(10);
        btnBuscar = new JButton("Iniciar Sesión");
        btnAtras = new JButton("<-");

        // Layout
        gbc.gridx = 0; gbc.gridy = 0;
        panelPrincipal.add(lblId, gbc);

        gbc.gridx = 1;
        panelPrincipal.add(txtIdProfesor, gbc);

        gbc.gridx = 1; gbc.gridy = 1;
        panelPrincipal.add(btnBuscar, gbc);

        // Panel de botones
        panelBotones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelBotones.add(btnAtras);

        // Agregar paneles al principal
        add(panelBotones, BorderLayout.NORTH);
        add(panelPrincipal, BorderLayout.CENTER);

        // Eventos
        btnBuscar.addActionListener(e -> buscarProfesor());
        btnAtras.addActionListener(e -> panel.mostrar(new FormularioInicio(panel)));
    }

    private void buscarProfesor() {
        try {
            String idStr = txtIdProfesor.getText();
            if (!idStr.matches("\\d+")) {
                JOptionPane.showMessageDialog(this, "Por favor ingrese un ID válido");
                return;
            }

            int id = Integer.parseInt(idStr);
            var profesor = profesorService.buscar(id);

            if (profesor != null) {
                panel.mostrar(new ProfesorPanel(panel, profesor));
            } else {
                JOptionPane.showMessageDialog(this, "Profesor no encontrado");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al buscar profesor: " + ex.getMessage());
        }
    }
}