package gui.Inicio;

import gui.PanelManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Clase que se encarga de mostrar el formulario de inicio con 3 botones para seleccionar el tipo de usuario
public class FormularioInicio extends JPanel {

    PanelManager panel;
    JPanel panelInicio;
    JButton botonProfesor;
    JButton botonAlumno;
    JButton botonAdministrador;

    public FormularioInicio(PanelManager panel) {
        this.panel = panel;
        setLayout(new GridBagLayout());
        armarFormulario();
    }

    public void armarFormulario() {
        panelInicio = new JPanel();
        panelInicio.setLayout(new GridLayout(3,1, 10, 10 ));
        botonProfesor = new JButton("Profesor");
        botonAlumno = new JButton("Alumno");
        botonAdministrador = new JButton("Administrador");

        panelInicio.add(this.botonProfesor);
        panelInicio.add(this.botonAlumno);
        panelInicio.add(this.botonAdministrador);

        add(this.panelInicio);

        botonProfesor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new ProfesorInicio(panel));
                panel.setJFrameTitle("Profesor");
            }
        });

        botonAlumno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new AlumnoInicio(panel));
                panel.setJFrameTitle("Alumno");
            }
        });

        botonAdministrador.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new formularioAdministracion(panel));
                panel.setJFrameTitle("Administracion");
            }
        });

    }

}

