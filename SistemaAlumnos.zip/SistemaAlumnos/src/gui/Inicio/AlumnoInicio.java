
package gui.Inicio;

import gui.Alumno.AlumnoPanel;
import gui.PanelManager;
import service.AlumnoService;
import javax.swing.*;
        import java.awt.*;

        //Formulario de inicio para el alumno que permite buscar un alumno por su ID para iniciar sesión
public class AlumnoInicio extends JPanel {
    private PanelManager panel;
    private AlumnoService alumnoService;

    private JPanel panelPrincipal;
    private JTextField txtIdAlumno;
    private JButton btnBuscar;
    private JButton btnAtras;

    public AlumnoInicio(PanelManager panel) {
        this.panel = panel;
        this.alumnoService = new AlumnoService();
        setLayout(new BorderLayout(10, 10));
        armarFormulario();
    }

    private void armarFormulario() {
        panelPrincipal = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Componentes
        JLabel lblId = new JLabel("ID Alumno:");
        txtIdAlumno = new JTextField(10);
        btnBuscar = new JButton("Iniciar Sesión");
        btnAtras = new JButton("<-");

        // Layout
        gbc.gridx = 0; gbc.gridy = 0;
        panelPrincipal.add(lblId, gbc);

        gbc.gridx = 1;
        panelPrincipal.add(txtIdAlumno, gbc);

        gbc.gridx = 1; gbc.gridy = 1;
        panelPrincipal.add(btnBuscar, gbc);

        // Panel de botones superior
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelBotones.add(btnAtras);

        add(panelBotones, BorderLayout.NORTH);
        add(panelPrincipal, BorderLayout.CENTER);

        // Eventos
        btnBuscar.addActionListener(e -> buscarAlumno());
        btnAtras.addActionListener(e -> panel.mostrar(new FormularioInicio(panel)));
    }

    private void buscarAlumno() {
        try {
            String idStr = txtIdAlumno.getText();
            if (!idStr.matches("\\d+")) {
                JOptionPane.showMessageDialog(this, "Por favor ingrese un ID válido");
                return;
            }

            int id = Integer.parseInt(idStr);
            var alumno = alumnoService.buscarAlumno(id);

            if (alumno != null) {
                panel.mostrar(new AlumnoPanel(panel, alumno));
            } else {
                JOptionPane.showMessageDialog(this, "Alumno no encontrado");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al buscar alumno: " + ex.getMessage());
        }
    }
}

