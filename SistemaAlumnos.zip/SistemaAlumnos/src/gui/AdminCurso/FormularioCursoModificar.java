package gui.AdminCurso;

import Controlador.Curso;
import gui.PanelManager;
import service.CursoService;
import service.ServiceException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Formulario para modificar un curso.
public class FormularioCursoModificar extends JPanel {
    // Paneles para organizar la vista
    private JPanel panelModificar;
    private JPanel panelAtras;

    private PanelManager panel;

    // Labels y campos de texto para cada atributo del curso
    private JLabel nombre;
    private JTextField nombreText;

    private JLabel precio;
    private JTextField precioText;

    private JLabel cupo;
    private JTextField cupoText;

    private JLabel notaAprobacion;
    private JTextField notaAprobacionText;

    private JLabel calificacionesRequeridas;
    private JTextField calificacionesRequeridasText;

    // Botones para modificar y regresar
    private JButton botonModificar;
    private JButton botonAtras;

    // Instancia del servicio de Curso
    private CursoService instance;

    // Constructor que recibe el panel manager y el curso a modificar
    public FormularioCursoModificar(PanelManager panel, Curso curso) {
        this.panel = panel;
        instance = new CursoService();
        setLayout(new GridBagLayout());
        armarFormulario(curso);
    }

    private void armarFormulario(Curso curso) {
        // Inicialización de paneles
        panelModificar = new JPanel();
        panelAtras = new JPanel();
        panelAtras.setLayout(new GridBagLayout());

        // Se utiliza un GridLayout para organizar los campos y el botón de modificar.
        // En este ejemplo se utilizan 6 filas y 2 columnas (se dejarán algunas celdas vacías)
        panelModificar.setLayout(new GridLayout(6, 2, 5, 5));

        // Inicialización de componentes y asignación de valores actuales del curso
        nombre = new JLabel("Nombre");
        nombreText = new JTextField(7);
        nombreText.setText(curso.getNombre());

        precio = new JLabel("Precio");
        precioText = new JTextField(7);
        precioText.setText(String.valueOf(curso.getPrecio()));

        cupo = new JLabel("Cupo");
        cupoText = new JTextField(7);
        cupoText.setText(String.valueOf(curso.getCupo()));

        notaAprobacion = new JLabel("Nota Aprobacion");
        notaAprobacionText = new JTextField(7);
        notaAprobacionText.setText(String.valueOf(curso.getNotaAprobacion()));

        calificacionesRequeridas = new JLabel("Calificaciones Parciales Requeridas");
        calificacionesRequeridasText = new JTextField(7);
        calificacionesRequeridasText.setText(String.valueOf(curso.getCalificacionesParcialesRequeridas()));

        botonModificar = new JButton("Modificar");

        // Botón para volver atrás
        botonAtras = new JButton("<-");
        panelAtras.add(botonAtras);

        // Agregar los componentes al panel de modificación
        panelModificar.add(nombre);
        panelModificar.add(nombreText);
        panelModificar.add(precio);
        panelModificar.add(precioText);
        panelModificar.add(cupo);
        panelModificar.add(cupoText);
        panelModificar.add(notaAprobacion);
        panelModificar.add(notaAprobacionText);
        panelModificar.add(calificacionesRequeridas);
        panelModificar.add(calificacionesRequeridasText);
        panelModificar.add(botonModificar);

        // Posicionar los paneles utilizando GridBagLayout
        GridBagConstraints gbcModificar = new GridBagConstraints();
        gbcModificar.gridx = 0;
        gbcModificar.gridy = 1;
        gbcModificar.weightx = 1;
        gbcModificar.weighty = 1;
        gbcModificar.fill = GridBagConstraints.NONE;
        add(panelModificar, gbcModificar);

        setPreferredSize(new Dimension(300, 200));

        GridBagConstraints gbcAtras = new GridBagConstraints();
        gbcAtras.gridx = 0;
        gbcAtras.gridy = 0;
        gbcAtras.anchor = GridBagConstraints.NORTHWEST;
        add(panelAtras, gbcAtras);

        // Acción del botón "Atrás": se retorna al panel de búsqueda o al panel que muestra el curso encontrado.
        botonAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Reemplace "FormularioCursoBuscar" por el panel adecuado en su aplicación
                panel.mostrar(new FormularioCursoBuscar(panel));
            }
        });

        // Acción del botón "Modificar"
        botonModificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Se obtienen los datos ingresados por el usuario
                String nombreStr = nombreText.getText();
                String precioStr = precioText.getText();
                String cupoStr = cupoText.getText();
                String notaAprobacionStr = notaAprobacionText.getText();
                String calificacionesStr = calificacionesRequeridasText.getText();

                // Validaciones básicas: que ningún campo esté vacío
                if (nombreStr.isEmpty() || precioStr.isEmpty() || cupoStr.isEmpty() ||
                        notaAprobacionStr.isEmpty() || calificacionesStr.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Todos los campos deben estar llenos");
                    return;
                }

                // Validación del nombre (solo letras y espacios)
                if (!nombreStr.matches("[a-zA-Z ]+")) {
                    JOptionPane.showMessageDialog(null, "El nombre solo puede contener letras");
                    return;
                }

                // Validaciones numéricas:
                if (!precioStr.matches("[0-9]*\\.?[0-9]+")) {
                    JOptionPane.showMessageDialog(null, "El precio debe ser un número (decimales con punto)");
                    return;
                }
                if (!cupoStr.matches("\\d+")) {
                    JOptionPane.showMessageDialog(null, "El cupo debe ser un número entero");
                    return;
                }
                if (!notaAprobacionStr.matches("[0-9]*\\.?[0-9]+")) {
                    JOptionPane.showMessageDialog(null, "La nota de aprobación debe ser un número (decimales con punto)");
                    return;
                }
                if (!calificacionesStr.matches("\\d+")) {
                    JOptionPane.showMessageDialog(null, "Las calificaciones parciales requeridas deben ser un número entero");
                    return;
                }

                // Creación de un nuevo objeto Curso utilizando el constructor con parámetros
                Curso cursoNuevo = new Curso(
                        curso.getId(),  // Mantenemos el mismo ID
                        nombreStr,
                        Double.parseDouble(precioStr),
                        Integer.parseInt(cupoStr),
                        Double.parseDouble(notaAprobacionStr),
                        Integer.parseInt(calificacionesStr)
                );

                // Se intenta modificar el curso a través del servicio
                try {
                    instance.modificarCurso(cursoNuevo);
                    // Luego de la modificación se navega al panel de búsqueda o listado de cursos.
                    panel.mostrar(new FormularioCursoBuscar(panel));
                    String mensaje = "Se modificó el curso con éxito. \nNuevos datos: \n" +
                            "Nombre: " + nombreStr + "\n" +
                            "Precio: " + precioStr + "\n" +
                            "Cupo: " + cupoStr + "\n" +
                            "Nota Aprobacion: " + notaAprobacionStr + "\n" +
                            "Calificaciones Parciales Requeridas: " + calificacionesStr + "\n";
                    JOptionPane.showMessageDialog(null, mensaje);
                } catch (ServiceException se) {
                    JOptionPane.showMessageDialog(null, "No se pudo modificar el curso");
                }
            }
        });
    }
}
