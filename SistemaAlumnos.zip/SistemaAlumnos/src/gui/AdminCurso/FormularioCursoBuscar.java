package gui.AdminCurso;

import Controlador.Curso;
import gui.PanelManager;
import service.CursoService;
import service.ServiceException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

// Formulario para buscar un curso.
public class FormularioCursoBuscar extends JPanel {
    JPanel panelBuscar;
    JPanel panelAtras;

    PanelManager panel;
    CursoService instance; // Se utiliza el servicio de cursos

    JLabel idLabel;
    JTextField idText;
    JButton botonBuscar;
    JButton botonAtras;
    JButton botonBuscarTodos;

    public FormularioCursoBuscar(PanelManager panel) {
        this.panel = panel;
        instance = new CursoService();
        setLayout(new GridBagLayout());
        armarFormulario();
    }

    public void armarFormulario() {
        panelBuscar = new JPanel();
        panelAtras = new JPanel();
        panelAtras.setLayout(new GridBagLayout());
        panelBuscar.setLayout(new GridLayout(3, 1, 10, 10));

        // Cambiamos el texto para que solicite el ID del Curso
        idLabel = new JLabel("Ingrese ID del Curso:");
        idText = new JTextField(7);
        botonBuscar = new JButton("Buscar");
        botonBuscarTodos = new JButton("Buscar Todos");
        botonAtras = new JButton("<-");

        GridBagConstraints gbcLabel = new GridBagConstraints();
        gbcLabel.gridx = 0;
        gbcLabel.gridy = 0;
        gbcLabel.weightx = 1;
        gbcLabel.weighty = 1;
        gbcLabel.fill = GridBagConstraints.NONE;
        panelBuscar.add(idLabel, gbcLabel);

        GridBagConstraints gbcTxt = new GridBagConstraints();
        gbcTxt.gridx = 1;
        gbcTxt.gridy = 0;
        gbcTxt.weightx = 1;
        gbcTxt.weighty = 1;
        gbcTxt.fill = GridBagConstraints.NONE;
        panelBuscar.add(idText, gbcTxt);

        GridBagConstraints gbcBotonBuscar = new GridBagConstraints();
        gbcBotonBuscar.gridx = 1;
        gbcBotonBuscar.gridy = 1;
        gbcBotonBuscar.weightx = 2;
        gbcBotonBuscar.weighty = 2;
        gbcBotonBuscar.fill = GridBagConstraints.NONE;
        panelBuscar.add(botonBuscar, gbcBotonBuscar);

        GridBagConstraints gbcBotonBuscarTodos = new GridBagConstraints();
        gbcBotonBuscarTodos.gridx = 1;
        gbcBotonBuscarTodos.gridy = 2;
        gbcBotonBuscarTodos.weightx = 2;
        gbcBotonBuscarTodos.weighty = 2;
        gbcBotonBuscarTodos.fill = GridBagConstraints.NONE;
        panelBuscar.add(botonBuscarTodos, gbcBotonBuscarTodos);

        GridBagConstraints gbcBuscar = new GridBagConstraints();
        gbcBuscar.gridx = 0;
        gbcBuscar.gridy = 1;
        gbcBuscar.weightx = 1;
        gbcBuscar.weighty = 1;
        gbcBuscar.fill = GridBagConstraints.NONE;
        add(panelBuscar, gbcBuscar);

        GridBagConstraints gbcAtras = new GridBagConstraints();
        gbcAtras.gridx = 0;
        gbcAtras.gridy = 0;
        gbcAtras.anchor = GridBagConstraints.NORTHWEST;
        add(botonAtras, gbcAtras);

        // Acción para buscar un curso por ID
        botonBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idStr = idText.getText();
                if (idStr.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "El campo de ID no puede estar vacío");
                } else if (!idStr.matches("[0-9]+")) {
                    JOptionPane.showMessageDialog(null, "El ID solo puede contener números");
                } else {
                    try {
                        int id = Integer.parseInt(idStr);
                        Curso curso = instance.buscar(id);
                        if (curso == null) {
                            JOptionPane.showMessageDialog(null, "No se encontró el curso solicitado");
                        } else {
                            // Se muestra el formulario que muestra los datos del curso encontrado
                            panel.mostrar(new FormularioCursoEncontrado(panel, curso));
                        }
                    } catch (ServiceException ex) {
                        JOptionPane.showMessageDialog(null, ex.getMessage());
                    }
                }
            }
        });

        // Acción para buscar y mostrar todos los cursos
        botonBuscarTodos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    ArrayList<Curso> cursos = instance.buscarTodos();
                    panel.mostrar(new FormularioListadoCurso(panel, cursos));
                } catch (ServiceException ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });

        // Acción para volver al formulario anterior
        botonAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new FormularioCrearCurso(panel));
            }
        });
    }
}