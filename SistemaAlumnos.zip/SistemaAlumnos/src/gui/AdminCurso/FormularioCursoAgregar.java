package gui.AdminCurso;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import gui.PanelManager;
import service.CursoService;
import Controlador.Curso;
import service.ServiceException;

// Formulario para agregar un curso.
public class FormularioCursoAgregar extends JPanel {
    JPanel panelAgregar;
    JPanel panelSec;
    PanelManager panel;
    JButton botonAtras;

    JLabel idLabel;
    JTextField idField;

    JLabel nombre;
    JTextField nombreText;

    JLabel precio;
    JTextField precioText;

    JLabel cupo;
    JTextField cupoText;

    JLabel notaAprobacion;
    JTextField notaAprobacionText;

    JLabel calificacionesParcialesRequeridas;
    JTextField calificacionesParcialesRequeridasText;

    JButton botonAgregar;

    CursoService cursoService;

    public FormularioCursoAgregar(PanelManager panel) {
        this.panel = panel;
        cursoService = new CursoService();
        setLayout(new GridBagLayout());
        armarFormulario();
    }

    public void armarFormulario() {
        panelAgregar = new JPanel();
        panelSec = new JPanel();
        panelAgregar.setLayout(new GridLayout(7, 2, 10, 10));

        botonAtras = new JButton("<-");
        botonAtras.setPreferredSize(new Dimension(50, 25));

        idLabel = new JLabel("ID del Curso:");
        idField = new JTextField(10); // Campo de texto para ingresar el ID


        nombre = new JLabel("Nombre del Curso");
        nombreText = new JTextField(7);

        precio = new JLabel("Precio");
        precioText = new JTextField(7);

        cupo = new JLabel("Cupo");
        cupoText = new JTextField(7);

        notaAprobacion = new JLabel("Nota de Aprobación");
        notaAprobacionText = new JTextField(7);

        calificacionesParcialesRequeridas = new JLabel("Calificaciones Parciales Requeridas");
        calificacionesParcialesRequeridasText = new JTextField(7);

        botonAgregar = new JButton("Agregar Curso");

        botonAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idText = idField.getText(); // Obtenemos el ID ingresado
                String nombre = nombreText.getText();
                String precio = precioText.getText();
                String cupo = cupoText.getText();
                String notaAprobacion = notaAprobacionText.getText();
                String calificacionesParcialesRequeridas = calificacionesParcialesRequeridasText.getText();

                // Validaciones de los campos
                if (idText.isEmpty() || nombre.isEmpty() || precio.isEmpty() || cupo.isEmpty()
                        || notaAprobacion.isEmpty() || calificacionesParcialesRequeridas.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Todos los campos deben estar llenos");
                } else if (!idText.matches("[0-9]+")) {
                    JOptionPane.showMessageDialog(null, "El ID debe ser un número entero.");
                } else if (!nombre.matches("[a-zA-Z\\s]+")) {
                    JOptionPane.showMessageDialog(null, "El nombre del curso solo puede contener letras");
                } else if (!precio.matches("[0-9]*\\.?[0-9]+")) {
                    JOptionPane.showMessageDialog(null, "El precio debe ser un número. Los números decimales se separan con punto.");
                } else if (!cupo.matches("[0-9]+")) {
                    JOptionPane.showMessageDialog(null, "El cupo debe ser un número entero.");
                } else if (!notaAprobacion.matches("[0-9]*\\.?[0-9]+")) {
                    JOptionPane.showMessageDialog(null, "La nota de aprobación debe ser un número.");
                } else if (!calificacionesParcialesRequeridas.matches("[0-9]+")) {
                    JOptionPane.showMessageDialog(null, "Las calificaciones parciales requeridas deben ser un número entero.");
                } else {
                    int id = Integer.parseInt(idText); // Convertir el ID a entero
                    Curso curso = new Curso(id, nombre, Double.parseDouble(precio), Integer.parseInt(cupo),
                            Double.parseDouble(notaAprobacion), Integer.parseInt(calificacionesParcialesRequeridas));

                    try {
                        cursoService.guardarCurso(curso);
                        JOptionPane.showMessageDialog(null, "Curso agregado exitosamente");
                    } catch (ServiceException ex) {
                        JOptionPane.showMessageDialog(null, "Error al agregar el curso: " + ex.getMessage());
                    }

                    // Limpiar los campos tras guardar
                    idField.setText("");
                    nombreText.setText("");
                    precioText.setText("");
                    cupoText.setText("");
                    notaAprobacionText.setText("");
                    calificacionesParcialesRequeridasText.setText("");
                }
            }
        });

        botonAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new FormularioCrearCurso(panel));
            }
        });

        panelAgregar.add(idLabel);
        panelAgregar.add(idField);
        panelAgregar.add(nombre);
        panelAgregar.add(nombreText);
        panelAgregar.add(precio);
        panelAgregar.add(precioText);
        panelAgregar.add(cupo);
        panelAgregar.add(cupoText);
        panelAgregar.add(notaAprobacion);
        panelAgregar.add(notaAprobacionText);
        panelAgregar.add(calificacionesParcialesRequeridas);
        panelAgregar.add(calificacionesParcialesRequeridasText);
        panelAgregar.add(botonAgregar);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.NONE;
        add(panelAgregar, gbc);

        GridBagConstraints gbcSec = new GridBagConstraints();
        gbcSec.gridx = 0;
        gbcSec.gridy = 0;
        gbcSec.weightx = 0;
        gbcSec.weighty = 0;
        gbcSec.fill = GridBagConstraints.NONE;
        add(panelSec, gbcSec);

        panelSec.setLayout(new BorderLayout());
        panelSec.setPreferredSize(new Dimension(50, 25));
        panelSec.add(botonAtras, BorderLayout.WEST);
    }
}

