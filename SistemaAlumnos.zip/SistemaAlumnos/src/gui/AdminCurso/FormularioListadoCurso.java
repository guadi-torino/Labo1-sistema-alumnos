package gui.AdminCurso;

import Controlador.Curso;
import gui.PanelManager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

// Formulario para mostrar un listado de cursos.
public class FormularioListadoCurso extends JPanel {
    private PanelManager panel;
    private JPanel panelListado;
    private JPanel panelAtras;
    private JTable table1;
    private DefaultTableModel modelo;
    private JButton botonAtras;

    // Constructor que recibe el panel manager y la lista de cursos a mostrar.
    public FormularioListadoCurso(PanelManager panel, ArrayList<Curso> cursos) {
        this.panel = panel;
        setLayout(new GridBagLayout());
        armarFormulario(cursos);
    }

    private void armarFormulario(ArrayList<Curso> cursos) {
        // Panel para el listado y para el botón de volver
        panelListado = new JPanel();
        panelAtras = new JPanel();
        botonAtras = new JButton("<-");
        panelAtras.add(botonAtras);

        // Crear el modelo de tabla y definir las columnas correspondientes.
        modelo = new DefaultTableModel();
        String[] columnas = {"ID", "Nombre", "Precio", "Cupo", "Nota Aprobacion", "Calificaciones Parciales Requeridas"};
        modelo.setColumnIdentifiers(columnas);

        // Rellenar el modelo con los datos de cada curso.
        for (Curso curso : cursos) {
            modelo.addRow(new Object[]{
                    curso.getId(),
                    curso.getNombre(),
                    curso.getPrecio(),
                    curso.getCupo(),
                    curso.getNotaAprobacion(),
                    curso.getCalificacionesParcialesRequeridas()
            });
        }

        // Crear la tabla y agregarla a un scroll pane.
        table1 = new JTable(modelo);
        JScrollPane scrollPane = new JScrollPane(table1);

        // Configurar el botón "Atrás" para volver al formulario de búsqueda de curso.
        botonAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Se asume que existe un formulario de búsqueda de curso llamado FormularioCursoBuscar.
                panel.mostrar(new FormularioCursoBuscar(panel));
            }
        });

        // Utilizando GridBagLayout para ubicar los componentes:
        // 1. Se agrega el scroll pane que contiene la tabla.
        GridBagConstraints gbcScroll = new GridBagConstraints();
        gbcScroll.gridx = 0;
        gbcScroll.gridy = 1;
        gbcScroll.weightx = 1;
        gbcScroll.weighty = 1;
        gbcScroll.fill = GridBagConstraints.BOTH;
        add(scrollPane, gbcScroll);

        // 2. Se agrega un panel (en este ejemplo se mantiene similar al original, aunque esté vacío).
        GridBagConstraints gbcListado = new GridBagConstraints();
        gbcListado.gridx = 0;
        gbcListado.gridy = 1;
        gbcListado.weightx = 1;
        gbcListado.weighty = 1;
        gbcListado.fill = GridBagConstraints.BOTH;
        add(panelListado, gbcListado);

        // 3. Se agrega el panel con el botón "Atrás" en la parte superior izquierda.
        GridBagConstraints gbcAtras = new GridBagConstraints();
        gbcAtras.gridx = 0;
        gbcAtras.gridy = 0;
        gbcAtras.anchor = GridBagConstraints.NORTHWEST;
        add(panelAtras, gbcAtras);
    }
}
