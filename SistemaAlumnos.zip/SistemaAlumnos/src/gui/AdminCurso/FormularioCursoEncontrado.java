package gui.AdminCurso;

import Controlador.Curso;
import gui.PanelManager;
import service.CursoService;
import service.ServiceException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Formulario para mostrar un curso encontrado.
public class FormularioCursoEncontrado extends JPanel {
    // Paneles para organizar la información y botones
    private JPanel panelDatos;
    private JPanel panelBotones;
    private JPanel panelAtras;

    // Etiquetas para mostrar la información del curso
    private JLabel labelId;
    private JLabel labelNombre;
    private JLabel labelPrecio;
    private JLabel labelCupo;
    private JLabel labelNotaAprobacion;
    private JLabel labelCalificaciones;

    // Referencia al PanelManager para gestionar el cambio de formularios
    private PanelManager panel;
    // Instancia del servicio de cursos
    private CursoService cursoService;

    // Botones para acciones
    private JButton botonModificar;
    private JButton botonEliminar;
    private JButton botonAtras;

    public FormularioCursoEncontrado(PanelManager panel, Curso curso) {
        this.panel = panel;
        cursoService = new CursoService();
        setLayout(new GridBagLayout());
        armarFormulario(curso);
    }

    private void armarFormulario(Curso curso) {
        // Inicialización de paneles
        panelDatos = new JPanel(new GridLayout(6, 1, 5, 5));
        panelBotones = new JPanel(new GridLayout(1, 2, 10, 10));
        panelAtras = new JPanel(new FlowLayout(FlowLayout.LEFT));

        // Creación de etiquetas con los datos del curso
        labelId = new JLabel("ID: " + curso.getId());
        labelNombre = new JLabel("Nombre: " + curso.getNombre());
        labelPrecio = new JLabel("Precio: " + curso.getPrecio());
        labelCupo = new JLabel("Cupo: " + curso.getCupo());
        labelNotaAprobacion = new JLabel("Nota Aprobación: " + curso.getNotaAprobacion());
        labelCalificaciones = new JLabel("Calificaciones Parciales Requeridas: " + curso.getCalificacionesParcialesRequeridas());

        // Agregar etiquetas al panel de datos
        panelDatos.add(labelId);
        panelDatos.add(labelNombre);
        panelDatos.add(labelPrecio);
        panelDatos.add(labelCupo);
        panelDatos.add(labelNotaAprobacion);
        panelDatos.add(labelCalificaciones);

        // Creación de botones de acción
        botonModificar = new JButton("Modificar");
        botonEliminar = new JButton("Eliminar");
        panelBotones.add(botonModificar);
        panelBotones.add(botonEliminar);

        botonAtras = new JButton("<-");
        panelAtras.add(botonAtras);

        // Acciones para el botón "Atrás"
        botonAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new FormularioCursoBuscar(panel));
            }
        });

        // Acción para modificar el curso (se asume la existencia de FormularioCursoModificar)
       botonModificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new FormularioCursoModificar(panel, curso));
            }
        });

        // Acción para eliminar el curso
        botonEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(
                        null,
                        "¿Está seguro de eliminar el curso?",
                        "Eliminar Curso",
                        JOptionPane.YES_NO_OPTION
                );
                if (respuesta == JOptionPane.YES_OPTION) {
                    try {
                        cursoService.eliminarCurso(curso.getId());
                        JOptionPane.showMessageDialog(null, "Curso eliminado correctamente");
                        panel.mostrar(new FormularioCursoBuscar(panel));
                    } catch (ServiceException ex) {
                        JOptionPane.showMessageDialog(null, "No se pudo eliminar el curso: " + ex.getMessage());
                    }
                }
            }
        });

        // Uso de GridBagConstraints para la disposición de los paneles
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Panel de "Atrás"
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        add(panelAtras, gbc);

        // Panel con los datos del curso
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(panelDatos, gbc);

        // Panel con los botones (Modificar y Eliminar)
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(panelBotones, gbc);
    }
}
