package gui.Alumno;

import Controlador.Alumno;
import Controlador.Curso;
import gui.PanelManager;
import service.AlumnoService;
import service.ServiceException;

import javax.swing.*;
import java.awt.*;
import java.util.Map;

// Muestra las calificaciones de un alumno.
public class VerCalificaciones extends JPanel{
    private PanelManager panel;
    private Alumno alumno;
    private AlumnoService alumnoService;

    public VerCalificaciones(PanelManager panel, Alumno alumno) {
        this.panel = panel;
        this.alumno = alumno;
        this.alumnoService = new AlumnoService();
        setLayout(new BorderLayout(10, 10));
        armarInterfaz();
    }

    private void armarInterfaz() {
        JPanel panelPrincipal = new JPanel(new BorderLayout());
        JLabel lblTitulo = new JLabel("Calificaciones de " + alumno.getNombre(), JLabel.CENTER);
        panelPrincipal.add(lblTitulo, BorderLayout.NORTH);

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);

        try {
            Map<Curso, String> calificaciones = alumnoService.obtenerCalificaciones(alumno.getId());
            StringBuilder sb = new StringBuilder();

            if (calificaciones.isEmpty()) {
                sb.append("No hay calificaciones disponibles.");
            } else {
                for (Map.Entry<Curso, String> entry : calificaciones.entrySet()) {
                    sb.append("Curso: ").append(entry.getKey().getNombre()).append("\n");
                    sb.append(entry.getValue()).append("\n\n");
                }
            }
            textArea.setText(sb.toString());
        } catch (ServiceException e) {
            textArea.setText("Error al obtener calificaciones: " + e.getMessage());
        }

        panelPrincipal.add(new JScrollPane(textArea), BorderLayout.CENTER);

        JButton btnVolver = new JButton("Volver");
        btnVolver.addActionListener(e -> {
            try {
                panel.mostrar(new AlumnoPanel(panel, alumno));
            } catch (ServiceException ex) {
                throw new RuntimeException(ex);
            }
        });
        panelPrincipal.add(btnVolver, BorderLayout.SOUTH);

        this.add(panelPrincipal, BorderLayout.CENTER);
    }
}
/*package gui.Alumno;

import Controlador.Alumno;
import Controlador.Curso;
import gui.PanelManager;
import service.AlumnoService;
import service.ServiceException;

import javax.swing.*;
import java.awt.*;
import java.util.Map;
import java.util.List;

public class VerCalificaciones extends JPanel{
    private PanelManager panel;
    private Alumno alumno;
    private AlumnoService alumnoService;

    public VerCalificaciones(PanelManager panel, Alumno alumno) {
        this.panel = panel;
        this.alumno = alumno;
        this.alumnoService = new AlumnoService();
        setLayout(new BorderLayout(10, 10));
        armarInterfaz();
    }

    private void armarInterfaz() {
        JPanel panelPrincipal = new JPanel(new BorderLayout());
        JLabel lblTitulo = new JLabel("Calificaciones de " + alumno.getNombre(), JLabel.CENTER);
        panelPrincipal.add(lblTitulo, BorderLayout.NORTH);

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);

        try {
            Map<Curso, Double> calificaciones = alumnoService.obtenerCalificaciones(alumno.getId());
            StringBuilder sb = new StringBuilder();

            if (calificaciones.isEmpty()) {
                sb.append("No hay calificaciones disponibles.");
            } else {
                for (Map.Entry<Curso, Double> entry : calificaciones.entrySet()) {
                    sb.append("Curso: ").append(entry.getKey().getNombre()).append("\n");
                    sb.append("Nota Final: ").append(entry.getValue()).append("\n\n");
                }
            }
            textArea.setText(sb.toString());
        } catch (ServiceException e) {
            textArea.setText("Error al obtener calificaciones: " + e.getMessage());
        }

        panelPrincipal.add(new JScrollPane(textArea), BorderLayout.CENTER);

        JButton btnVolver = new JButton("Volver");
        btnVolver.addActionListener(e -> {
            try {
                panel.mostrar(new AlumnoPanel(panel, alumno));
            } catch (ServiceException ex) {
                throw new RuntimeException(ex);
            }
        });
        panelPrincipal.add(btnVolver, BorderLayout.SOUTH);

        this.add(panelPrincipal, BorderLayout.CENTER);
    }

}*/
