package gui.Alumno;

import gui.Inicio.FormularioInicio;
import gui.PanelManager;
import Controlador.Alumno;
import service.AlumnoService;
import service.ServiceException;

import javax.swing.*;
import java.awt.*;

// Panel principal para el alumno, donde se muestran las opciones disponibles y cerrar sesión.
public class AlumnoPanel extends JPanel {
    private PanelManager panel;
    private Alumno alumno;
    private AlumnoService alumnoService;

    public AlumnoPanel(PanelManager panel, Alumno alumno) throws ServiceException {
        this.panel = panel;
        this.alumno = alumno;
        this.alumnoService = new AlumnoService();
        setLayout(new BorderLayout(10, 10));
        try {
            armarFormulario();
        } catch (ServiceException e) {
            throw new RuntimeException(e);
        }
    }

    private void armarFormulario() throws ServiceException {
        // Panel Principal
        JPanel panelPrincipal = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Información del alumno
        JLabel lblBienvenida = new JLabel("Bienvenido, " + alumno.getNombre());
        JLabel lblCursosActivos = new JLabel("Cursos activos: "
          +alumnoService.obtenerCursosInscritos(alumno.getId()).size() + "/3");

        // Botones de acciones
        JButton btnVerCursos = new JButton("Ver Mis Cursos");
        JButton btnVerCalificaciones = new JButton("Ver Calificaciones");
        JButton btnInscribirse = new JButton("Inscribirme a un Curso");
        JButton btnSalir = new JButton("Cerrar Sesión");

        // Layout
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panelPrincipal.add(lblBienvenida, gbc);

        gbc.gridy = 1;
        panelPrincipal.add(lblCursosActivos, gbc);

        gbc.gridy = 2;
        gbc.gridwidth = 1;
        panelPrincipal.add(btnVerCursos, gbc);

        gbc.gridx = 1;
        panelPrincipal.add(btnVerCalificaciones, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panelPrincipal.add(btnInscribirse, gbc);

        gbc.gridy = 4;
        panelPrincipal.add(btnSalir, gbc);

        add(panelPrincipal, BorderLayout.CENTER);


        btnVerCursos.addActionListener(e ->
                panel.mostrar(new AlumnoCursosPanel(panel, alumno)));

        btnVerCalificaciones.addActionListener(e ->
                panel.mostrar(new VerCalificaciones(panel, alumno)));


        btnInscribirse.addActionListener(e ->
                panel.mostrar(new FormularioRegistroCurso(panel,alumno)));


        btnSalir.addActionListener(e ->
                panel.mostrar(new FormularioInicio(panel)));
    }


    }

