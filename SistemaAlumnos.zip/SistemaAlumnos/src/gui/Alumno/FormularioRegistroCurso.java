package gui.Alumno;

import Controlador.Alumno;
import Controlador.Curso;
import gui.PanelManager;
import service.AlumnoService;
import service.CursoService;
import service.ServiceException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;


// Formulario para que el alumno pueda inscribirse en un curso.
public class FormularioRegistroCurso extends JPanel {
    private PanelManager panel;
    private AlumnoService alumnoService;
    private CursoService cursoService;
    private Alumno alumno;

    private JComboBox<Curso> comboCursos;
    private JLabel lblCupo;
    private JLabel lblPrecio;
    private JButton btnRegistrar;
    private JButton btnEliminarInscripcion;

    private JButton botonAtras;

    public FormularioRegistroCurso(PanelManager panel, Alumno alumno) {
        this.panel = panel;
        this.alumno = alumno;
        this.alumnoService = new AlumnoService();
        this.cursoService = new CursoService();

        setLayout(new BorderLayout(10, 10));
        armarFormulario();
    }

    private void armarFormulario() {
        JPanel panelPrincipal = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        comboCursos = new JComboBox<>();
        lblCupo = new JLabel("Cupo disponible: ");
        lblPrecio = new JLabel("Precio: ");
        btnRegistrar = new JButton("Registrar en Curso");
        btnEliminarInscripcion = new JButton("Eliminar Inscripción");

        gbc.gridx = 0; gbc.gridy = 0;
        panelPrincipal.add(new JLabel("Curso:"), gbc);

        gbc.gridx = 1;
        panelPrincipal.add(comboCursos, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2;
        panelPrincipal.add(lblCupo, gbc);

        gbc.gridy = 2;
        panelPrincipal.add(lblPrecio, gbc);

        gbc.gridy = 3;
        panelPrincipal.add(btnRegistrar, gbc);
        gbc.gridy = 4;
        panelPrincipal.add(btnEliminarInscripcion, gbc);

        add(panelPrincipal, BorderLayout.CENTER);

        cargarCursos();

        comboCursos.addActionListener(e -> actualizarInfoCurso());
        btnRegistrar.addActionListener(e -> registrarAlumno());
        btnEliminarInscripcion.addActionListener(e -> eliminarInscripcion());


        // Configurar el botón "Atrás" para volver al formulario de búsqueda de alumnos.
        botonAtras = new JButton("Atrás");
        botonAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    panel.mostrar(new AlumnoPanel(panel,alumno));
                } catch (ServiceException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        // Agregar el botón en la parte inferior
        JPanel panelBoton = new JPanel();
        panelBoton.add(botonAtras);
        add(panelBoton, BorderLayout.SOUTH);
    }


    private void cargarCursos() {
        try {
            List<Curso> cursos = cursoService.buscarTodos();
            comboCursos.removeAllItems();
            for (Curso curso : cursos) {
                comboCursos.addItem(curso);
            }
            actualizarInfoCurso();
        } catch (ServiceException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar cursos: " + e.getMessage());
        }
    }

    private void actualizarInfoCurso() {
        Curso curso = (Curso) comboCursos.getSelectedItem();
        if (curso != null) {
            lblCupo.setText("Cupo disponible: " + curso.getCupo());
            lblPrecio.setText("Precio: $" + curso.getPrecio());
        }
    }

    private void registrarAlumno() {
        Curso curso = (Curso) comboCursos.getSelectedItem();

        if (curso == null) {
            JOptionPane.showMessageDialog(this, "Seleccione un curso");
            return;
        }

        try {
            if (!alumno.inscribirCurso(curso)) {
                JOptionPane.showMessageDialog(this, "No es posible inscribirse en el curso. Puede que esté lleno o que el alumno haya alcanzado el límite.");
                return;
            }

            if (curso.getCupo() <= 0) {
                JOptionPane.showMessageDialog(this, "No hay cupo disponible en este curso");
                return;
            }

            alumnoService.inscribirACurso(alumno.getId(), curso.getId());
            JOptionPane.showMessageDialog(this, "Inscripción realizada con éxito");
            actualizarInfoCurso();

        } catch (ServiceException e) {
            JOptionPane.showMessageDialog(this, "Error al registrar alumno: " + e.getMessage());
        }
    }

    private void eliminarInscripcion() {
        Curso curso = (Curso) comboCursos.getSelectedItem();
        if (curso == null) {
            JOptionPane.showMessageDialog(this, "Seleccione un curso");
            return;
        }

        try {
            alumnoService.eliminarInscripcion(alumno.getId(), curso.getId());
            JOptionPane.showMessageDialog(this, "Inscripción eliminada con éxito");
            actualizarInfoCurso();
        } catch (ServiceException e) {
            JOptionPane.showMessageDialog(this, "Error al eliminar inscripción: " + e.getMessage());
        }
    }
}


