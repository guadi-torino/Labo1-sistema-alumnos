package gui.Alumno;

import Controlador.Alumno;
import Controlador.Curso;
import gui.PanelManager;
import service.AlumnoService;
import service.ServiceException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

// Muestra los cursos en los que está inscrito un alumno.
public class AlumnoCursosPanel extends JPanel {
    private PanelManager panel;
    private Alumno alumno;
    private AlumnoService alumnoService;
    private JList<String> listaCursos;
    private JButton botonAtras;

    public AlumnoCursosPanel(PanelManager panel, Alumno alumno) {
        this.panel=panel;
        this.alumno = alumno;
        this.alumnoService = new AlumnoService();
        armarPanel();
    }

    private void armarPanel() {
        setLayout(new BorderLayout());
        JLabel labelTitulo = new JLabel("Cursos Inscritos", SwingConstants.CENTER);
        add(labelTitulo, BorderLayout.NORTH);

        listaCursos = new JList<>();
        cargarCursos();

        JScrollPane scrollPane = new JScrollPane(listaCursos);
        add(scrollPane, BorderLayout.CENTER);

        // Configurar el botón "Atrás" para volver al formulario de búsqueda de alumnos.
        botonAtras = new JButton("Atrás");
        botonAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    panel.mostrar(new AlumnoPanel(panel,alumno));
                } catch (ServiceException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        // Agregar el botón en la parte inferior
        JPanel panelBoton = new JPanel();
        panelBoton.add(botonAtras);
        add(panelBoton, BorderLayout.SOUTH);
    }



   private void cargarCursos() {
       //  List<Curso> cursos = alumnoService.obtenerCursosInscritos(alumno.getId());
       List<Curso> cursos = alumno.getCursosInscritos();
       DefaultListModel<String> model = new DefaultListModel<>();
       for (Curso curso : cursos) {
           model.addElement(curso.getNombre());
       }
       listaCursos.setModel(model);


   }
}

