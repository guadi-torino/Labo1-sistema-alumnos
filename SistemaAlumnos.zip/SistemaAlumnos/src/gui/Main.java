package gui;
import Controlador.Administrador;
import Controlador.Profesor;
import Model.DAOAlumno;
import Model.DAOException;
import Controlador.Alumno;
import Controlador.Curso;

//En el archivo Main.java
public class Main {
    public static void main(String[] args) {
        System.out.println("Inicio del programa");
        PanelManager panelManager = new PanelManager();

    }
}