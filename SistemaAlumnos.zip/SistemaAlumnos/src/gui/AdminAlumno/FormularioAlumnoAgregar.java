package gui.AdminAlumno;

import Controlador.Alumno;
import gui.PanelManager;
import service.AlumnoService;
import service.ServiceException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

// Formulario para agregar un alumno.
public class FormularioAlumnoAgregar extends JPanel{
    private PanelManager panel; // Se asume que existe una clase PanelManager para gestionar los paneles
    private JButton botonAtras;

    private JLabel idLabel;
    private JTextField idField;

    private JLabel nombreLabel;
    private JTextField nombreField;

    private JLabel emailLabel;
    private JTextField emailField;

    private JButton botonAgregar;

    private AlumnoService alumnoService;

    public FormularioAlumnoAgregar(PanelManager panel) {
        this.panel = panel;
        alumnoService = new AlumnoService();
        setLayout(new GridBagLayout());
        armarFormulario();
    }

    private void armarFormulario() {
        // Panel para los campos del formulario
        JPanel panelAgregar = new JPanel();
        panelAgregar.setLayout(new GridLayout(4, 2, 10, 10));

        // Panel para el botón "Atrás"
        JPanel panelSec = new JPanel(new BorderLayout());
        panelSec.setPreferredSize(new Dimension(50, 25));

        botonAtras = new JButton("<-");
        botonAtras.setPreferredSize(new Dimension(50, 25));
        // Acción para volver al panel anterior (ajusta según la navegación de tu aplicación)
        botonAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Por ejemplo, se asume que existe un formulario previo para la gestión de alumnos
                panel.mostrar(new FormularioAltaAlumno(panel));
            }
        });
        panelSec.add(botonAtras, BorderLayout.WEST);

        // Campos del formulario
        idLabel = new JLabel("ID del Alumno:");
        idField = new JTextField(10);

        nombreLabel = new JLabel("Nombre del Alumno:");
        nombreField = new JTextField(10);

        emailLabel = new JLabel("Email del Alumno:");
        emailField = new JTextField(10);

        // Botón para agregar el alumno
        botonAgregar = new JButton("Agregar Alumno");
        botonAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idText = idField.getText().trim();
                String nombre = nombreField.getText().trim();
                String email = emailField.getText().trim();

                // Validaciones básicas
                if (idText.isEmpty() || nombre.isEmpty() || email.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Todos los campos deben estar llenos");
                    return;
                }
                if (!idText.matches("[0-9]+")) {
                    JOptionPane.showMessageDialog(null, "El ID debe ser un número entero.");
                    return;
                }
                if (!nombre.matches("[a-zA-Z\\s]+")) {
                    JOptionPane.showMessageDialog(null, "El nombre solo puede contener letras");
                    return;
                }
                if (!email.matches("^(.+)@(.+)$")) {
                    JOptionPane.showMessageDialog(null, "El email no tiene un formato correcto.");
                    return;
                }

                int id = Integer.parseInt(idText);
                Alumno alumno = new Alumno(id, nombre, email, new ArrayList<>());

                try {
                    alumnoService.guardarAlumno(alumno);
                    JOptionPane.showMessageDialog(null, "Alumno agregado exitosamente");

                    // Limpiar los campos luego de guardar
                    idField.setText("");
                    nombreField.setText("");
                    emailField.setText("");
                } catch (ServiceException ex) {
                    JOptionPane.showMessageDialog(null, "Error al agregar el alumno: " + ex.getMessage());
                }
            }
        });

        // Agregar los componentes al panel del formulario
        panelAgregar.add(idLabel);
        panelAgregar.add(idField);
        panelAgregar.add(nombreLabel);
        panelAgregar.add(nombreField);
        panelAgregar.add(emailLabel);
        panelAgregar.add(emailField);
        // Se agrega el botón en la última celda; se agrega un componente vacío para completar la grilla
        panelAgregar.add(botonAgregar);
        panelAgregar.add(new JLabel("")); // celda vacía

        // Ubicación de los paneles en el FormularioAlumnoAgregar usando GridBagLayout
        GridBagConstraints gbcSec = new GridBagConstraints();
        gbcSec.gridx = 0;
        gbcSec.gridy = 0;
        gbcSec.anchor = GridBagConstraints.NORTHWEST;
        add(panelSec, gbcSec);

        GridBagConstraints gbcForm = new GridBagConstraints();
        gbcForm.gridx = 0;
        gbcForm.gridy = 1;
        gbcForm.weightx = 1;
        gbcForm.weighty = 1;
        gbcForm.fill = GridBagConstraints.NONE;
        add(panelAgregar, gbcForm);
    }
}
