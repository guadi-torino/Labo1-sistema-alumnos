package gui.AdminAlumno;

import Controlador.Alumno;
import gui.PanelManager;
import service.AlumnoService;
import service.ServiceException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Formulario para mostrar un alumno encontrado por su ID y permitir su modificación o eliminación.
public class FormularioAlumnoEncontrado extends JPanel {
    // Paneles para organizar la información y los botones
    private JPanel panelDatos;
    private JPanel panelBotones;
    private JPanel panelAtras;

    // Etiquetas para mostrar la información del alumno
    private JLabel labelId;
    private JLabel labelNombre;
    private JLabel labelEmail;

    // Referencia al PanelManager para gestionar el cambio de formularios
    private PanelManager panel;
    // Instancia del servicio de alumnos
    private AlumnoService alumnoService;

    // Botones para acciones
    private JButton botonModificar;
    private JButton botonEliminar;
    private JButton botonAtras;

    public FormularioAlumnoEncontrado(PanelManager panel, Alumno alumno) {
        this.panel = panel;
        alumnoService = new AlumnoService();
        setLayout(new GridBagLayout());
        armarFormulario(alumno);
    }

    private void armarFormulario(Alumno alumno) {
        // Inicialización de paneles
        panelDatos = new JPanel(new GridLayout(3, 1, 5, 5));
        panelBotones = new JPanel(new GridLayout(1, 2, 10, 10));
        panelAtras = new JPanel(new FlowLayout(FlowLayout.LEFT));

        // Creación de etiquetas con los datos del alumno
        labelId = new JLabel("ID: " + alumno.getId());
        labelNombre = new JLabel("Nombre: " + alumno.getNombre());
        labelEmail = new JLabel("Email: " + alumno.getEmail());

        // Agregar etiquetas al panel de datos
        panelDatos.add(labelId);
        panelDatos.add(labelNombre);
        panelDatos.add(labelEmail);

        // Creación de botones de acción
        botonModificar = new JButton("Modificar");
        botonEliminar = new JButton("Eliminar");
        panelBotones.add(botonModificar);
        panelBotones.add(botonEliminar);

        botonAtras = new JButton("<-");
        panelAtras.add(botonAtras);

        // Acción para el botón "Atrás": regresa al formulario de búsqueda de alumnos
        botonAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new FormularioAlumnoBuscar(panel));
            }
        });

        // Acción para modificar el alumno (se asume la existencia de FormularioAlumnoModificar)
        botonModificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new FormularioAlumnoModificar(panel, alumno));
            }
        });

        // Acción para eliminar el alumno
        botonEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(
                        null,
                        "¿Está seguro de eliminar el alumno?",
                        "Eliminar Alumno",
                        JOptionPane.YES_NO_OPTION
                );
                if (respuesta == JOptionPane.YES_OPTION) {
                    try {
                        alumnoService.eliminarAlumno(alumno.getId());
                        JOptionPane.showMessageDialog(null, "Alumno eliminado correctamente");
                        panel.mostrar(new FormularioAlumnoBuscar(panel));
                    } catch (ServiceException ex) {
                        JOptionPane.showMessageDialog(null, "No se pudo eliminar el alumno: " + ex.getMessage());
                    }
                }
            }
        });

        // Uso de GridBagConstraints para la disposición de los paneles
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Panel de "Atrás"
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        add(panelAtras, gbc);

        // Panel con los datos del alumno
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(panelDatos, gbc);

        // Panel con los botones (Modificar y Eliminar)
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(panelBotones, gbc);
    }
}
