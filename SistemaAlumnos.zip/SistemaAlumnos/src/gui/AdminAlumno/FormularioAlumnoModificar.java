package gui.AdminAlumno;

import Controlador.Alumno;
import gui.PanelManager;
import service.AlumnoService;
import service.ServiceException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

// Formulario para modificar un alumno existente.
public class FormularioAlumnoModificar extends JPanel {
    // Paneles para organizar la vista
    private JPanel panelModificar;
    private JPanel panelAtras;

    private PanelManager panel;

    // Componentes para los atributos del alumno
    // Se muestra el id (no editable) y se permiten modificar el nombre y el email
    private JLabel labelId;
    private JLabel nombre;
    private JTextField nombreText;
    private JLabel email;
    private JTextField emailText;

    // Botones para modificar y regresar
    private JButton botonModificar;
    private JButton botonAtras;

    // Instancia del servicio de Alumno
    private AlumnoService alumnoService;

    // Constructor que recibe el PanelManager y el alumno a modificar
    public FormularioAlumnoModificar(PanelManager panel, Alumno alumno) {
        this.panel = panel;
        alumnoService = new AlumnoService();
        setLayout(new GridBagLayout());
        armarFormulario(alumno);
    }

    private void armarFormulario(Alumno alumno) {
        // Inicialización de paneles
        // Se utiliza un GridLayout de 4 filas y 2 columnas para organizar los componentes
        panelModificar = new JPanel(new GridLayout(4, 2, 5, 5));
        panelAtras = new JPanel(new GridBagLayout());

        // Se crea la etiqueta para mostrar el ID (no editable)
        labelId = new JLabel("ID: " + alumno.getId());

        // Inicialización de componentes para el nombre
        nombre = new JLabel("Nombre:");
        nombreText = new JTextField(7);
        nombreText.setText(alumno.getNombre());

        // Inicialización de componentes para el email
        email = new JLabel("Email:");
        emailText = new JTextField(7);
        emailText.setText(alumno.getEmail());

        // Botón para modificar
        botonModificar = new JButton("Modificar");

        // Botón para regresar
        botonAtras = new JButton("<-");
        panelAtras.add(botonAtras);

        // Se agregan los componentes al panel de modificación
        // La primera fila muestra el ID (se ocupa la primera celda) y se deja una celda vacía
        panelModificar.add(labelId);
        panelModificar.add(new JLabel(""));  // Celda vacía para alinear

        // Segunda fila: Nombre y su campo de texto
        panelModificar.add(nombre);
        panelModificar.add(nombreText);

        // Tercera fila: Email y su campo de texto
        panelModificar.add(email);
        panelModificar.add(emailText);

        // Cuarta fila: Botón de modificar (se agrega en la primera celda) y se deja la segunda vacía
        panelModificar.add(botonModificar);
        panelModificar.add(new JLabel(""));  // Celda vacía

        // Posicionamiento de los paneles en el formulario usando GridBagLayout

        // Panel de modificación se coloca en la posición central
        GridBagConstraints gbcModificar = new GridBagConstraints();
        gbcModificar.gridx = 0;
        gbcModificar.gridy = 1;
        gbcModificar.weightx = 1;
        gbcModificar.weighty = 1;
        gbcModificar.fill = GridBagConstraints.NONE;
        add(panelModificar, gbcModificar);

        // Se define un tamaño preferido para el formulario
        setPreferredSize(new Dimension(300, 200));

        // Panel para el botón "Atrás" se ubica en la esquina superior izquierda
        GridBagConstraints gbcAtras = new GridBagConstraints();
        gbcAtras.gridx = 0;
        gbcAtras.gridy = 0;
        gbcAtras.anchor = GridBagConstraints.NORTHWEST;
        add(panelAtras, gbcAtras);

        // Acción para el botón "Atrás": regresa al formulario de búsqueda de alumnos
        botonAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new FormularioAlumnoBuscar(panel));
            }
        });

        // Acción para el botón "Modificar": se validan los campos, se crea el objeto Alumno modificado y se actualiza
        botonModificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombreStr = nombreText.getText().trim();
                String emailStr = emailText.getText().trim();

                // Validaciones básicas
                if (nombreStr.isEmpty() || emailStr.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Todos los campos deben estar llenos");
                    return;
                }
                // Validación para el nombre: solo letras y espacios
                if (!nombreStr.matches("[a-zA-Z\\s]+")) {
                    JOptionPane.showMessageDialog(null, "El nombre solo puede contener letras y espacios");
                    return;
                }
                // Validación básica para el formato del email
                if (!emailStr.matches("^(.+)@(.+)$")) {
                    JOptionPane.showMessageDialog(null, "El email no tiene un formato correcto");
                    return;
                }

                // Creación de un nuevo objeto Alumno manteniendo el mismo ID
                Alumno alumnoNuevo = new Alumno(alumno.getId(), nombreStr, emailStr, new ArrayList<>());

                // Se intenta modificar el alumno a través del servicio
                try {
                    alumnoService.modificarAlumno(alumnoNuevo);
                    // Luego de la modificación se regresa al formulario de búsqueda
                    panel.mostrar(new FormularioAlumnoBuscar(panel));
                    String mensaje = "Se modificó el alumno con éxito. \nNuevos datos: \n" +
                            "Nombre: " + nombreStr + "\n" +
                            "Email: " + emailStr + "\n";
                    JOptionPane.showMessageDialog(null, mensaje);
                } catch (ServiceException se) {
                    JOptionPane.showMessageDialog(null, "No se pudo modificar el alumno: " + se.getMessage());
                }
            }
        });
    }
}
