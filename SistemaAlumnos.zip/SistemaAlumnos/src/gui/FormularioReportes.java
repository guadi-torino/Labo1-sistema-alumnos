package gui;

import Controlador.Alumno;
import Controlador.Curso;
import gui.Alumno.AlumnoPanel;
import gui.Inicio.formularioAdministracion;
import service.CursoService;
import service.ReporteService;
import service.ServiceException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

// Muestra un formulario para generar reportes de recaudación de un curso.
public class FormularioReportes extends JPanel {
    private PanelManager panel;
    private ReporteService reporteService;
    private CursoService cursoService;

    private JComboBox<Curso> comboCursos;
    private JTextArea textAreaReporte;
    private JButton jButtonGenerar;
    private JButton botonAtras;

    public FormularioReportes(PanelManager panel) {
        this.panel=panel;
        this.reporteService = new ReporteService();
        this.cursoService = new CursoService();
        armarFormulario();
    }

    // Configura los componentes del formulario.
    private void armarFormulario() {
        setLayout(new BorderLayout());

        JPanel panelSuperior = new JPanel(new FlowLayout());
        JLabel jLabelCurso = new JLabel("Seleccionar Curso:");
        comboCursos = new JComboBox<>();
        jButtonGenerar = new JButton("Generar Reporte");

        // Cargar los cursos en el ComboBox
        cargarCursos();

        panelSuperior.add(jLabelCurso);
        panelSuperior.add(comboCursos);
        panelSuperior.add(jButtonGenerar);

        textAreaReporte = new JTextArea(20, 50);
        textAreaReporte.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textAreaReporte);

        add(panelSuperior, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        jButtonGenerar.addActionListener(e -> generarReporte());
        // Configurar el botón "Atrás" para volver al formulario de búsqueda de alumnos.
        botonAtras = new JButton("Atrás");
        botonAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.mostrar(new formularioAdministracion(panel));
            }
        });

        // Agregar el botón en la parte inferior
        JPanel panelBoton = new JPanel();
        panelBoton.add(botonAtras);
        add(panelBoton, BorderLayout.SOUTH);
    }

    // Carga los cursos en el ComboBox
    private void cargarCursos() {
        try {
            List<Curso> cursos = cursoService.buscarTodos();
            comboCursos.removeAllItems();
            for (Curso curso : cursos) {
                comboCursos.addItem(curso);
            }
        } catch (ServiceException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar cursos: " + e.getMessage());
        }
    }

    // Genera el reporte de recaudación del curso seleccionado. Muestra el reporte en el TextArea.
    private void generarReporte() {
        Curso cursoSeleccionado = (Curso) comboCursos.getSelectedItem();

        if (cursoSeleccionado == null) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar un curso.");
            return;
        }

        try {
            String reporte = reporteService.generarReporteRecaudacion(cursoSeleccionado);
            textAreaReporte.setText(reporte);
        } catch (ServiceException e) {
            JOptionPane.showMessageDialog(this, "Error al generar el reporte: " + e.getMessage());
        }
    }



}
