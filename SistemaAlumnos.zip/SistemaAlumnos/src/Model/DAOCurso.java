package Model;

import Controlador.Curso;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// Clase que implementa la interfaz DAO y se encarga de realizar las operaciones CRUD en la base de datos para la clase Curso
public class DAOCurso implements DAO<Curso> {
    private final String DB_JDBC_DRIVER = "org.h2.Driver";
    private final String DB_URL = "jdbc:h2:file:C:\\Users\\guadi\\Desktop\\Basededatos";
    private final String DB_USER = "sa";
    private final String DB_PASSWORD = "";

    @Override
    public void guardar(Curso elemento) throws DAOException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO Curso VALUES (?, ?, ?, ?, ?, ?)")) {
            preparedStatement.setInt(1, elemento.getId());
            preparedStatement.setString(2, elemento.getNombre());
            preparedStatement.setDouble(3, elemento.getPrecio());
            preparedStatement.setInt(4, elemento.getCupo());
            preparedStatement.setDouble(5, elemento.getNotaAprobacion());
            preparedStatement.setInt(6, elemento.getCalificacionesParcialesRequeridas());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new DAOException("Error al guardar Curso: " + e.getMessage());
        }
    }

    @Override
    public void modificar(Curso elemento) throws DAOException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("UPDATE Curso SET nombre = ?, precio = ?, cupo = ?, nota_aprobacion = ?, calificaciones_parciales_requeridas = ? WHERE id = ?")) {

            preparedStatement.setString(1, elemento.getNombre());
            preparedStatement.setDouble(2, elemento.getPrecio());
            preparedStatement.setInt(3, elemento.getCupo());
            preparedStatement.setDouble(4, elemento.getNotaAprobacion());
            preparedStatement.setInt(5, elemento.getCalificacionesParcialesRequeridas());
            preparedStatement.setInt(6, elemento.getId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new DAOException("Error al modificar Curso: " + e.getMessage());
        }
    }

    @Override
    public void eliminar(int id) throws DAOException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM Curso WHERE id = ?")) {

            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new DAOException("Error al eliminar Curso: " + e.getMessage());
        }
    }
    @Override
    public Curso buscar(int id) throws DAOException {
        Curso curso = null;
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Curso WHERE id = ?")) {

            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                curso = new Curso(
                        resultSet.getInt("id"),
                        resultSet.getString("nombre"),
                        resultSet.getDouble("precio"),
                        resultSet.getInt("cupo"),
                        resultSet.getDouble("nota_aprobacion"),
                        resultSet.getInt("calificaciones_parciales_requeridas")
                );
            }
        } catch (SQLException e) {
            throw new DAOException("Error al buscar Curso: " + e.getMessage());
        }
        return curso;
    }


    @Override
    public ArrayList<Curso> buscarTodos() throws DAOException {
        ArrayList<Curso> cursos = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM Curso")) {

            while (resultSet.next()) {
                Curso curso = new Curso(
                        resultSet.getInt("id"),
                        resultSet.getString("nombre"),
                        resultSet.getDouble("precio"),
                        resultSet.getInt("cupo"),
                        resultSet.getDouble("nota_aprobacion"),
                        resultSet.getInt("calificaciones_parciales_requeridas")
                );
                cursos.add(curso);
            }
        } catch (SQLException e) {
            throw new DAOException("Error al buscar todos los Cursos: " + e.getMessage());
        }
        return cursos;
    }

    // Obtiene solo los cursos cuyos IDs están en la lista ids
    public ArrayList<Curso> buscarCursos(List<Integer> ids) throws DAOException {
        ArrayList<Curso> cursos = new ArrayList<>();
        for (int id : ids) {
            cursos.add(buscar(id));
        }
        return cursos;
    }

    // Método para obtener la CANTIDAD de cursos inscritos por un alumno (Para reporte)
    public int obtenerCantidadAlumnosCurso(int cursoId) throws DAOException {
        String sql = "SELECT COUNT(*) AS cantidad FROM Alumno_Curso WHERE curso_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setInt(1, cursoId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("cantidad");
            }
        } catch (SQLException e) {
            throw new DAOException("Error al obtener la cantidad de alumnos: " + e.getMessage());
        }
        return 0;
    }

}


