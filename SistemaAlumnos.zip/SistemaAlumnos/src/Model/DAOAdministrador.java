package Model;
import Controlador.Administrador;
import Controlador.Alumno;
import Controlador.Curso;

import java.sql.*;
import java.util.ArrayList;
// Clase que implementa la interfaz DAO y se encarga de realizar las operaciones CRUD en la base de datos para la clase Administrador
public class DAOAdministrador implements DAO<Administrador> {
    private final String DB_JDBC_DRIVER = "org.h2.Driver";
    private final String DB_URL = "jdbc:h2:file:C:\\Users\\guadi\\Desktop\\Basededatos";
    private final String DB_USER = "sa";
    private final String DB_PASSWORD = "";

    @Override
    public void guardar(Administrador elemento) throws DAOException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO Administrador(id, nombre, email) VALUES (?, ?, ?)")) {

            preparedStatement.setInt(1, elemento.getId());
            preparedStatement.setString(2, elemento.getNombre());
            preparedStatement.setString(3, elemento.getEmail());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new DAOException("Error al guardar Administrador: " + e.getMessage());
        }
    }

    @Override
    public void modificar(Administrador elemento) throws DAOException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("UPDATE Administrador SET nombre = ?, email = ? WHERE id = ?")) {

            preparedStatement.setString(1, elemento.getNombre());
            preparedStatement.setString(2, elemento.getEmail());
            preparedStatement.setInt(3, elemento.getId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new DAOException("Error al modificar Administrador: " + e.getMessage());
        }
    }

    @Override
    public void eliminar(int id) throws DAOException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM Administrador WHERE id = ?")) {

            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new DAOException("Error al eliminar Administrador: " + e.getMessage());
        }
    }

    @Override
    public Administrador buscar(int id) throws DAOException {
        Administrador admin = null;
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Administrador WHERE id = ?")) {

            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                admin = new Administrador(resultSet.getInt("id"), resultSet.getString("nombre"), resultSet.getString("email"));
            }
        } catch (SQLException e) {
            throw new DAOException("Error al buscar Administrador: " + e.getMessage());
        }
        return admin;
    }

    @Override
    public ArrayList<Administrador> buscarTodos() throws DAOException {
        ArrayList<Administrador> administradores = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM Administrador")) {

            while (resultSet.next()) {
                Administrador admin = new Administrador(resultSet.getInt("id"), resultSet.getString("nombre"), resultSet.getString("email"));
                administradores.add(admin);
            }
        } catch (SQLException e) {
            throw new DAOException("Error al buscar todos los Administradores: " + e.getMessage());
        }
        return administradores;
    }

}


