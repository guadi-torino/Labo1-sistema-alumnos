package Model;
import Controlador.Profesor;
import java.sql.*;
import java.util.ArrayList;

// Clase que implementa la interfaz DAO y se encarga de realizar las operaciones CRUD en la base de datos para la clase Profesor
public class DAOProfesor implements DAO<Profesor> {
    private final String DB_JDBC_DRIVER = "org.h2.Driver";
    private final String DB_URL = "jdbc:h2:file:C:\\Users\\guadi\\Desktop\\Basededatos";
    private final String DB_USER = "sa";
    private final String DB_PASSWORD = "";

    @Override
    public void guardar(Profesor elemento) throws DAOException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO Profesor VALUES (?, ?, ?)")) {

            preparedStatement.setInt(1, elemento.getId());
            preparedStatement.setString(2, elemento.getNombre());
            preparedStatement.setString(3, elemento.getEmail());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new DAOException("Error al guardar Profesor: " + e.getMessage());
        }
    }

    @Override
    public void modificar(Profesor elemento) throws DAOException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("UPDATE Profesor SET nombre = ?, email = ? WHERE id = ?")) {

            preparedStatement.setString(1, elemento.getNombre());
            preparedStatement.setString(2, elemento.getEmail());
            preparedStatement.setInt(3, elemento.getId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new DAOException("Error al modificar Profesor: " + e.getMessage());
        }
    }

    @Override
    public void eliminar(int id) throws DAOException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM Profesor WHERE id = ?")) {

            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new DAOException("Error al eliminar Profesor: " + e.getMessage());
        }
    }
    @Override
    public Profesor buscar(int id) throws DAOException {
        Profesor profesor = null;
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Profesor WHERE id = ?")) {

            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                profesor = new Profesor(resultSet.getInt("id"), resultSet.getString("nombre"), resultSet.getString("email"));
            }
        } catch (SQLException e) {
            throw new DAOException("Error al buscar Profesor: " + e.getMessage());
        }
        return profesor;
    }

    @Override
    public ArrayList<Profesor> buscarTodos() throws DAOException {
        ArrayList<Profesor> profesores = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM Profesor")) {

            while (resultSet.next()) {
                Profesor profesor = new Profesor(resultSet.getInt("id"), resultSet.getString("nombre"), resultSet.getString("email"));
                profesores.add(profesor);
            }
        } catch (SQLException e) {
            throw new DAOException("Error al buscar todos los Profesores: " + e.getMessage());
        }
        return profesores;
    }

// Método que asigna la nota final de un alumno en un curso específico en la base de datos
    public void asignarNotaFinal(int profesorId, int alumnoId, int cursoId, double notaFinal) throws DAOException {
        // Se ignora profesorId ya que la tabla no tiene esa columna
        String sqlUpdate = "UPDATE Notas_Finales SET nota_final = ? WHERE alumno_id = ? AND curso_id = ?";
        String sqlInsert = "INSERT INTO Notas_Finales (alumno_id, curso_id, nota_final) VALUES (?, ?, ?)";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            // Intentamos actualizar primero
            try (PreparedStatement psUpdate = connection.prepareStatement(sqlUpdate)) {
                psUpdate.setDouble(1, notaFinal);
                psUpdate.setInt(2, alumnoId);
                psUpdate.setInt(3, cursoId);
                int rowsUpdated = psUpdate.executeUpdate();
                if (rowsUpdated == 0) { // No existe la fila, se inserta
                    try (PreparedStatement psInsert = connection.prepareStatement(sqlInsert)) {
                        psInsert.setInt(1, alumnoId);
                        psInsert.setInt(2, cursoId);
                        psInsert.setDouble(3, notaFinal);
                        psInsert.executeUpdate();
                    }
                }
            }
        } catch (SQLException e) {
            throw new DAOException("Error al asignar nota final: " + e.getMessage());
        }
    }



    //NO USO
    public int obtenerCantidadNotasParciales(int alumnoId, int cursoId) throws DAOException {
        String sql = "SELECT COUNT(*) AS total FROM CalificacionesParciales WHERE alumno_id = ? AND curso_id = ?";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setInt(1, alumnoId);
            preparedStatement.setInt(2, cursoId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("total");
            }
        } catch (SQLException e) {
            throw new DAOException("Error al obtener la cantidad de notas parciales: " + e.getMessage());
        }
        return 0;
    }

    public void asignarNotaParcial(int profesorId, int alumnoId, int cursoId, double nota) throws DAOException {
        String sqlInsert = "INSERT INTO CalificacionesParciales (alumno_id, curso_id, profesor_id, nota) VALUES (?, ?, ?, ?)";
        String sqlUpdate = "UPDATE CalificacionesParciales SET nota = ? WHERE alumno_id = ? AND curso_id = ? AND profesor_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement psUpdate = connection.prepareStatement(sqlUpdate);
             PreparedStatement psInsert = connection.prepareStatement(sqlInsert)) {

            // Intentar actualizar la nota si ya existe
            psUpdate.setDouble(1, nota);
            psUpdate.setInt(2, alumnoId);
            psUpdate.setInt(3, cursoId);
            psUpdate.setInt(4, profesorId);

            int rowsUpdated = psUpdate.executeUpdate();

            if (rowsUpdated == 0) { // Si no existe, insertar la nueva nota
                psInsert.setInt(1, alumnoId);
                psInsert.setInt(2, cursoId);
                psInsert.setInt(3, profesorId);
                psInsert.setDouble(4, nota);
                psInsert.executeUpdate();
            }

        } catch (SQLException e) {
            throw new DAOException("Error al asignar nota parcial: " + e.getMessage());
        }
    }
}


