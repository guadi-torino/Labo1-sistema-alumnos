package Model;

import Controlador.Alumno;
import Controlador.Curso;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// Clase que implementa la interfaz DAO y se encarga de realizar las operaciones CRUD en la base de datos para la clase Alumno
public class DAOAlumno implements DAO<Alumno> {
    private final String DB_JDBC_DRIVER = "org.h2.Driver";
    private final String DB_URL = "jdbc:h2:file:C:\\Users\\guadi\\Desktop\\Basededatos";
    private final String DB_USER = "sa";
    private final String DB_PASSWORD = "";

    // Instancia de la clase DAOCurso para poder realizar operaciones CRUD en la tabla Curso
    private final DAOCurso daoCurso = new DAOCurso();


    @Override
    public void guardar(Alumno elemento) throws DAOException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO Alumno (id, nombre, email) VALUES (?, ?, ?)")) {

            preparedStatement.setInt(1, elemento.getId());
            preparedStatement.setString(2, elemento.getNombre());
            preparedStatement.setString(3, elemento.getEmail());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new DAOException("Error al guardar Alumno: " + e.getMessage());
        }
    }

    @Override
    public void modificar(Alumno elemento) throws DAOException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("UPDATE Alumno SET nombre = ?, email = ? WHERE id = ?")) {

            preparedStatement.setString(1, elemento.getNombre());
            preparedStatement.setString(2, elemento.getEmail());
            preparedStatement.setInt(3, elemento.getId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new DAOException("Error al modificar Alumno: " + e.getMessage());
        }
    }

    @Override
    public void eliminar(int id) throws DAOException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM Alumno WHERE id = ?")) {

            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new DAOException("Error al eliminar Alumno: " + e.getMessage());
        }
    }

    @Override
    public ArrayList<Alumno> buscarTodos() throws DAOException {
        ArrayList<Alumno> alumnos = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM Alumno")) {

            while (resultSet.next()) {
                Alumno alumno = new Alumno(
                        resultSet.getInt("id"),
                        resultSet.getString("nombre"),
                        resultSet.getString("email"),
                        daoCurso.buscarCursos(obtenerCursosInscritos(resultSet.getInt("id")))
                );
                alumnos.add(alumno);
            }
        } catch (SQLException e) {
            throw new DAOException("Error al buscar todos los Alumnos: " + e.getMessage());
        }
        return alumnos;
    }

    @Override
    public Alumno buscar(int id) throws DAOException {
        Alumno alumno = null;
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Alumno WHERE id = ?")) {

            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                alumno = new Alumno(
                        resultSet.getInt("id"),
                        resultSet.getString("nombre"),
                        resultSet.getString("email"),
                        daoCurso.buscarCursos(obtenerCursosInscritos(id))
                );
            }
        } catch (SQLException e) {
            throw new DAOException("Error al buscar Alumno: " + e.getMessage());
        }
        return alumno;
    }

    // Método para inscribir un alumno a un curso en la base de datos (tabla Alumno_Curso)
    public void inscribirACurso(int alumnoId, int cursoId) throws DAOException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO Alumno_Curso (alumno_id, curso_id) VALUES (?, ?)")) {

            preparedStatement.setInt(1, alumnoId);
            preparedStatement.setInt(2, cursoId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new DAOException("Error al inscribir Alumno a Curso: " + e.getMessage());
        }
    }

    // Método para eliminar la inscripción de un alumno en un curso en la base de datos (tabla Alumno_Curso)
    public void eliminarInscripcionDeCurso(int alumnoId, int cursoId) throws DAOException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM Alumno_Curso WHERE alumno_id = ? AND curso_id = ?")) {

            preparedStatement.setInt(1, alumnoId);
            preparedStatement.setInt(2, cursoId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new DAOException("Error al eliminar inscripción de Alumno en Curso: " + e.getMessage());
        }
    }

    // Método para obtener todos los cursos en los que está inscrito un alumno a partir de su id
    public List<Integer> obtenerCursosInscritos(int alumnoId) throws DAOException {
        List<Integer> cursosIds = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT curso_id FROM Alumno_Curso WHERE alumno_id = ?")) {

            preparedStatement.setInt(1, alumnoId);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                cursosIds.add(resultSet.getInt("curso_id"));
            }
        } catch (SQLException e) {
            throw new DAOException("Error al obtener cursos inscritos de Alumno: " + e.getMessage());
        }
        return cursosIds;
    }


    // Método para obtener la nota final de un alumno en un curso a partir de sus ids de alumno y curso
    public Double obtenerNotaFinal(int alumnoId, int cursoId) throws DAOException {
        String sql = "SELECT nota_final FROM Notas_Finales WHERE alumno_id = ? AND curso_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setInt(1, alumnoId);
            preparedStatement.setInt(2, cursoId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getDouble("nota_final");
            }
        } catch (SQLException e) {
            throw new DAOException("Error al obtener nota final: " + e.getMessage());
        }
        return null;
    }

//lista de alumnos inscritos en un curso específico, consultando la tabla intermedia Alumno_Curso
// devuelve una lista de objetos Alumno con su id, nombre y email.
    public List<Alumno> obtenerAlumnosPorCurso(int cursoId) throws DAOException {
        List<Alumno> alumnos = new ArrayList<>();
        String sql = "SELECT a.id, a.nombre, a.email " +
                "FROM Alumno a " +
                "INNER JOIN Alumno_Curso ac ON a.id = ac.alumno_id " +
                "WHERE ac.curso_id = ?";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, cursoId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String email = rs.getString("email");
                alumnos.add(new Alumno(id, nombre, email, null));
            }
        } catch (SQLException e) {
            throw new DAOException("Error al obtener alumnos para el curso: " + e.getMessage());
        }
        return alumnos;
    }



// Método para obtener las calificaciones parciales de un alumno en un curso (NO LO USE)
    public List<Double> obtenerCalificacionesParciales(int alumnoId, int cursoId) throws DAOException {
        List<Double> notas = new ArrayList<>();
        String sql = "SELECT nota FROM Calificaciones_Parciales WHERE alumno_id = ? AND curso_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setInt(1, alumnoId);
            preparedStatement.setInt(2, cursoId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                notas.add(resultSet.getDouble("nota"));
            }
        } catch (SQLException e) {
            throw new DAOException("Error al obtener calificaciones parciales: " + e.getMessage());
        }
        return notas;
    }
}
