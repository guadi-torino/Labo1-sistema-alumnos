package Model;

public class DAOException extends Exception {
    // Constructor que recibe un mensaje de error
    public DAOException(String message) {
        super(message);
    }
}
