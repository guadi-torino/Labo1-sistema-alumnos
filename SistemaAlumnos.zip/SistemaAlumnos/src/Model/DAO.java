package Model;

import java.util.ArrayList;

public interface DAO <T>{
    // Método para guardar un elemento en la base de datos
    public void guardar(T elemento) throws DAOException;
    // Método para modificar un elemento en la base de datos
    public void modificar(T elemento) throws DAOException;
    // Método para eliminar un elemento en la base de datos
    public void eliminar(int id) throws DAOException;
    // Método para buscar un elemento en la base de datos a partir de su id que pasa por parámetro
    public T buscar(int id) throws DAOException;
    // Método para buscar todos los elementos en la base de datos y devolverlos en un ArrayList
    public ArrayList<T> buscarTodos() throws DAOException;


}
