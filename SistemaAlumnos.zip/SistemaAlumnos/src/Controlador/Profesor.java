package Controlador;
// Clase Profesor que representa a un profesor, extiende la funcionalidad de la clase Usuario
public class Profesor extends Usuario {

    // Constructor que inicializa los atributos del profesor utilizando el constructor de la clase Usuario
    public Profesor(int id, String nombre, String email) {
        super(id, nombre, email);
    }

    // Método para asignar una nota parcial a un alumno en un curso
    public void asignarNotaParcial(Alumno alumno, Curso curso, double nota) {
        curso.asignarNotaParcial(alumno, nota);
    }

    // Método para asignar una nota final a un alumno en un curso
    public void asignarNotaFinal(Alumno alumno, Curso curso, double nota) {
            curso.asignarNotaFinal(alumno, nota);
    }

}

