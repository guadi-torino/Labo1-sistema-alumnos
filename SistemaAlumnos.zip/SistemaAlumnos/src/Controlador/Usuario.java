package Controlador;

// Clase abstracta que sirve como base para diferentes tipos de usuarios (Administrador, Profesor, Alumno)
public abstract class Usuario {
    protected int id;
    protected String nombre;
    protected String email;

    // Constructor que inicializa los atributos comunes de los usuarios
    public Usuario(int id, String nombre, String email) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
    }

    // Método público que retorna el ID del usuario
    public int getId() {
        return id;
    }
    // Método público que retorna el nombre del usuario
    public String getNombre() {
        return nombre;
    }
    // Método público que retorna el correo electrónico del usuario
    public String getEmail() {
        return email;
    }
}
