package Controlador;
import java.util.ArrayList;
import java.util.List;

// Clase Reporte que genera reportes de recaudación y aprobados
public class Reporte {
    public static void generarReporteRecaudacion(List<Curso> cursos) {
        System.out.println("Reporte de recaudación:");
        for (Curso curso : cursos) {// Recorre la lista de cursos
            System.out.println("Curso: " + curso.getNombre() + " - Recaudación: $" + curso.calcularRecaudacion());
        }
    }

    // Método para generar un reporte de alumnos aprobados en los cursos
    public static void generarReporteAprobados(List<Curso> cursos) {
        System.out.println("Reporte de alumnos aprobados:");
        for (Curso curso : cursos) {
            long aprobados = curso.getNotasFinales().entrySet().stream()// Obtiene las notas finales de los alumnos
                    .filter(entry -> entry.getValue() >= curso.getNotaAprobacion())// Filtra las notas aprobadas
                    .count();// Cuenta las notas aprobadas
            System.out.println("Curso: " + curso.getNombre() + " - Aprobados: " + aprobados + " / Inscritos: " + curso.getAlumnos().size());
        }
    }
}
