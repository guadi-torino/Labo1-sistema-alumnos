package Controlador;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Clase Curso que representa a un curso
public class Curso {
    private int id;
    private String nombre;
    private double precio;
    private int cupo;
    private double notaAprobacion;
    private int calificacionesParcialesRequeridas;
    private List<Alumno> alumnos;// Lista de alumnos inscritos en el curso
    private Map<Alumno, List<Double>> calificacionesParciales;// Mapa de calificaciones parciales de los alumnos
    private Map<Alumno, Double> notasFinales;// Mapa de notas finales de los alumnos

    // Constructor que inicializa los atributos de un curso
    public Curso(int id, String nombre, double precio, int cupo, double notaAprobacion, int calificacionesParcialesRequeridas) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.cupo = cupo;
        this.notaAprobacion = notaAprobacion;
        this.calificacionesParcialesRequeridas = calificacionesParcialesRequeridas;
        this.alumnos = new ArrayList<>();
        this.calificacionesParciales = new HashMap<>();
        this.notasFinales = new HashMap<>();
    }

    // Método para agregar un alumno a la lista de alumnos inscritos en el curso
    public boolean agregarAlumno(Alumno alumno) {
        if (alumnos.size() < cupo) {// Verifica si el curso tiene cupo disponible
            alumnos.add(alumno);// Agrega al alumno a la lista de alumnos inscritos
            calificacionesParciales.put(alumno, new ArrayList<>());// Inicializa la lista de calificaciones parciales del alumno
            return true;// Retorna verdadero si el alumno fue agregado exitosamente
        }
        return false; // Retorna falso si el curso no tiene cupo disponible
    }

    // Método para calcular la nota final de un alumno
    public void asignarNotaParcial(Alumno alumno, double nota) {
        if (calificacionesParciales.containsKey(alumno)) { // Verifica si el alumno está inscrito en el curso
            calificacionesParciales.get(alumno).add(nota);// Agrega la calificación parcial del alumno
        }
    }

    // Método para asignar la nota final de un alumno
    public void asignarNotaFinal(Alumno alumno, double nota) {
        if (calificacionesParciales.containsKey(alumno) && // Verifica si el alumno está inscrito en el curso
                calificacionesParciales.get(alumno).size() >= calificacionesParcialesRequeridas) {// Verifica si el alumno tiene suficientes calificaciones parciales
            notasFinales.put(alumno, nota);// Asigna la nota final del alumno
        }
    }

    // Método para calcular la recaudación total del curso
    public double calcularRecaudacion() {
        return alumnos.size() * precio;
    }

    // Método público que retorna el ID del curso
    public int getCupo() {
        return cupo - alumnos.size();
    }

    // Método público que retorna el nombre del curso
    public String getNombre() {
        return nombre;
    }

    // Método público que retorna el ID del curso
    public Map<Alumno, Double> getNotasFinales() {
        return notasFinales;
    }

    // Método público que retorna el ID del curso
    public List<Alumno> getAlumnos() {
        return alumnos;
    }

    // Método público que retorna el ID del curso
    public double getNotaAprobacion() {
        return notaAprobacion;
    }

    // Método público que retorna el ID del curso
    public int getId() {
        return id;
    }


    public void setId(int id) {
        this.id = id;
    }


    public double getPrecio() {
        return precio;
    }

    public int getCalificacionesParcialesRequeridas() {
        return calificacionesParcialesRequeridas;
    }
    /* Dentro de la clase Curso
    public int getCantidadCalificacionesParciales(Alumno alumno) {
        List<Double> notas = calificacionesParciales.get(alumno);
        return notas != null ? notas.size() : 0;
    }
*/
    @Override
    // Método para representar un objeto Curso como una cadena de texto
    public String toString() {
        return nombre; // O cualquier otro atributo que identifique claramente el curso
    }


}

