package Controlador;
import java.util.ArrayList;
import java.util.List;


//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
        public static void main(String[] args) {
            // Administrador crea cursos
            Administrador admin = new Administrador(1, "Admin", "admin@example.com");
            Curso curso1 = admin.crearCurso(101, "Java Básico", 500.0, 5, 7.0, 3);
            Curso curso2 = admin.crearCurso(102, "Python Avanzado", 700.0, 3, 8.0, 2);

            // Registra alumnos
            Alumno alumno1 = admin.registrarAlumno(1, "Sonia", "sonia@example.com");
            Alumno alumno2 = admin.registrarAlumno(2, "Guadi", "guadi@example.com");

            // Inscribe alumnos
            alumno1.inscribirCurso(curso1);
            alumno2.inscribirCurso(curso1);

            // Profesor asigna notas
            Profesor profesor = new Profesor(2, "Profesor", "profesor@example.com");
            profesor.asignarNotaParcial(alumno1, curso1, 7.0);
            profesor.asignarNotaParcial(alumno1, curso1, 8.0);
            profesor.asignarNotaParcial(alumno1, curso1, 9.0);
            profesor.asignarNotaFinal(alumno1, curso1, 8.5);

            // Generar reportes
            List<Curso> cursos = new ArrayList<>();
            cursos.add(curso1);
            cursos.add(curso2);

            // Reporte de recaudación
            Reporte.generarReporteRecaudacion(cursos);
            Reporte.generarReporteAprobados(cursos);
        }
    }
