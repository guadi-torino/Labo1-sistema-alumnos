package Controlador;

import java.util.ArrayList;

// Clase que representa a un administrador, extiende la funcionalidad de la clase Usuario
public class Administrador extends Usuario {

    // Constructor que inicializa los atributos del administrador utilizando el constructor de la clase Usuario
    public Administrador(int id, String nombre, String email) {
        super(id, nombre, email);// Llama al constructor de la clase base Usuario para asignar id, nombre y email
    }

    // Método para crear un nuevo curso con los parámetros especificados
    public Curso crearCurso(int id, String nombre, double precio, int cupo, double notaAprobacion, int calificacionesParcialesRequeridas) {
        return new Curso(id, nombre, precio, cupo, notaAprobacion, calificacionesParcialesRequeridas);
    }

    // Método para registrar un nuevo alumno con los parámetros especificados
    public Alumno registrarAlumno(int id, String nombre, String email) {
        return new Alumno(id, nombre, email, new ArrayList<>());
    }
}

