package Controlador;

import java.util.ArrayList;
import java.util.List;

// Clase Alumno que representa a un alumno
public class Alumno {
    private int id;
    private String nombre;
    private String email;
    private List<Curso> cursosInscritos; // Lista de cursos inscritos por el alumno
    private final int maxCursos = 3;// Número máximo de cursos en los que se puede inscribir un alumno

    // Constructor que inicializa los atributos de un alumno
    public Alumno(int id, String nombre, String email, List<Curso> cursosInscritos) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
        this.cursosInscritos = cursosInscritos;
    }

    // Método para inscribir un curso en la lista de cursos inscritos del alumno
    public boolean inscribirCurso(Curso curso) {
        if (cursosInscritos.size() < maxCursos && curso.getCupo() > 0) {// Verifica si el alumno puede inscribirse en el curso
            cursosInscritos.add(curso);// Agrega el curso a la lista de cursos inscritos
            curso.agregarAlumno(this);// Agrega al alumno a la lista de alumnos inscritos en el curso
            return true;
        }
        return false;
    }

    // Método para finalizar un curso en la lista de cursos inscritos del alumno
    public void finalizarCurso(Curso curso) {
        cursosInscritos.remove(curso);
    }

    // Método público que retorna el ID del alumno
    public int getId() {
        return id;
    }

    // Método público que retorna el nombre del alumno
    public String getNombre() {
        return nombre;
    }

    // Método público que retorna la lista de cursos inscritos por el alumno
    public List<Curso> getCursosInscritos() {
        return cursosInscritos;
    }

    // Método público que retorna el correo electrónico del alumno
    public String getEmail() {
        return email;
    }
    @Override
    // Método para representar un objeto Alumno como una cadena de texto
    public String toString() {
        return nombre; // O cualquier otro atributo que identifique claramente el curso
    }
}
