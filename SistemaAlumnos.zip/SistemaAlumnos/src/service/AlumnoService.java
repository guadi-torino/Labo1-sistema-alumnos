package service;

import Controlador.Alumno;
import Controlador.Curso;
import Model.DAOAlumno;
import Model.DAOCurso;
import Model.DAOException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

//Servicio para gestionar operaciones relacionadas con la entidad Alumno
public class AlumnoService {
    private DAOAlumno daoAlumno;
    private DAOCurso daoCurso;

    // Constructor que inicializa el DAOAlumno
    public AlumnoService() {
        daoAlumno=new DAOAlumno();
        daoCurso = new DAOCurso();
    }

    // Método para guardar un alumno
    public void guardarAlumno(Alumno alumno) throws ServiceException {
        try {
            daoAlumno.guardar(alumno);
        } catch (DAOException e) {
            // Capturar excepción DAO y lanzar una ServiceException
            throw new ServiceException(e.getMessage());
        }
    }

    // Método para modificar un alumno
    public void modificarAlumno(Alumno alumno) throws ServiceException {
        try {
            daoAlumno.modificar(alumno);
        } catch (DAOException e) {
            // Capturar excepción DAO y lanzar una ServiceException
            throw new ServiceException(e.getMessage());
        }
    }

    // Método para eliminar un alumno por su legajo
    public void eliminarAlumno(int legajo) throws ServiceException
    {
        try{
            daoAlumno.eliminar(legajo);
        }
        catch (DAOException e)
        {
            // Capturar excepción DAO y lanzar una ServiceException
            throw  new ServiceException(e.getMessage());
        }
    }
    //Método para buscar un alumno por su ID (si existe en DAO)
    public Alumno buscarAlumno(int id) throws ServiceException {
        try {
            return daoAlumno.buscar(id);
        } catch (DAOException e) {
            throw new ServiceException("Error al buscar el alumno: " + e.getMessage());
        }
    }

    // Método para obtener todos los alumnos (si existe en DAO)
    public List<Alumno> buscarTodosLosAlumnos() throws ServiceException {
        try {
            return daoAlumno.buscarTodos();
        } catch (DAOException e) {
            throw new ServiceException("Error al obtener la lista de alumnos: " + e.getMessage());
        }
    }

    // Método para inscribir un alumno a un curso
    public void inscribirACurso(int alumnoId, int cursoId) throws ServiceException {
        try {
            daoAlumno.inscribirACurso(alumnoId, cursoId);
        } catch (DAOException e) {
            throw new ServiceException("Error al inscribir al alumno en el curso: " + e.getMessage());
        }
    }
    // Método para obtener la cantidad de cursos inscritos por un alumno
    public List<Integer> obtenerCursosInscritos(int alumnoId) throws ServiceException {
        try {
            return daoAlumno.obtenerCursosInscritos(alumnoId);
        } catch (DAOException e) {
            throw new ServiceException("Error al obtener cursos inscritos del alumno: " + e.getMessage());
        }
    }

    // Método para obtener la lista de los alumnos inscritos en un curso
    public List<Alumno> obtenerAlumnosPorCurso(int cursoId) throws ServiceException {
        try {
            return daoAlumno.obtenerAlumnosPorCurso(cursoId);
        } catch (DAOException e) {
            throw new ServiceException("Error al obtener alumnos del curso: " + e.getMessage());
        }
    }

    // Método para ver la nota final de un alumno en un curso y su estado(APROBADO,DESAPROBADO,CURSANDO)
    public Map<Curso, String> obtenerCalificaciones(int alumnoId) throws ServiceException {
        try {
            Map<Curso, String> calificaciones = new HashMap<>();
            List<Integer> cursosInscritos = daoAlumno.obtenerCursosInscritos(alumnoId);

            for (Integer cursoId : cursosInscritos) {
                Curso curso = daoCurso.buscar(cursoId);
                if (curso == null) {
                    System.out.println("No se encontró el curso con ID: " + cursoId);
                    continue;
                }

                Double notaFinal = daoAlumno.obtenerNotaFinal(alumnoId, cursoId);
                String estado;

                if (notaFinal == null || notaFinal == 0.0) {
                    estado = "CURSANDO";
                } else if (notaFinal >= curso.getNotaAprobacion()) {
                    estado = "APROBADO";
                } else {
                    estado = "DESAPROBADO";
                }

                calificaciones.put(curso, "Nota Final: " + (notaFinal != null ? notaFinal : "N/A") + " - " + estado);
            }
            return calificaciones;
        } catch (DAOException e) {
            throw new ServiceException("Error al obtener calificaciones: " + e.getMessage());
        }
    }

    // Método para eliminar la inscripción de un alumno en un curso
  public void eliminarInscripcion(int alumnoId, int cursoId) throws ServiceException {
      try {
          List<Integer> cursosInscritos = daoAlumno.obtenerCursosInscritos(alumnoId);
          if (!cursosInscritos.contains(cursoId)) {
              throw new ServiceException("El alumno no está inscrito en este curso.");
          }
          daoAlumno.eliminarInscripcionDeCurso(alumnoId, cursoId);
          System.out.println("Inscripción eliminada con éxito para el alumno ID: " + alumnoId + " en el curso ID: " + cursoId);
      } catch (DAOException e) {
          throw new ServiceException("Error al eliminar inscripción del curso: " + e.getMessage());
      }
  }

}