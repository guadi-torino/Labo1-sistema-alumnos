package service;

import Controlador.Administrador;
import Controlador.Profesor;
import Model.DAOProfesor;
import Model.DAOException;

import java.util.ArrayList;

public class ProfesorService {
    private DAOProfesor daoProfesor;

    // Constructor que inicializa el DAOProfesor
    public ProfesorService() {
        daoProfesor = new DAOProfesor();
    }

    // Método para guardar un profesor
    public void guardarProfesor(Profesor profesor) throws ServiceException {
        try {
            daoProfesor.guardar(profesor);
        } catch (DAOException e) {
            throw new ServiceException(e.getMessage());
        }
    }

    // Método para modificar un profesor
    public void modificarProfesor(Profesor profesor) throws ServiceException {
        try {
            daoProfesor.modificar(profesor);
        } catch (DAOException e) {
            throw new ServiceException(e.getMessage());
        }
    }

    // Método para eliminar un profesor por su ID
    public void eliminarProfesor(int id) throws ServiceException {
        try {
            daoProfesor.eliminar(id);
        } catch (DAOException e) {
            throw new ServiceException(e.getMessage());
        }
    }
    public Profesor buscar (int id) throws ServiceException{
        try{
            return daoProfesor.buscar(id);
        }catch (DAOException d){
            throw new ServiceException(d.getMessage());
        }

    }

    public ArrayList<Profesor> buscarTodos() throws ServiceException {
        try{
            return daoProfesor.buscarTodos();
        }catch (DAOException d){
            throw new ServiceException(d.getMessage());
        }
    }

  // Método para asignar una calificación final a un alumno
    public void asignarCalificacionFinal(int profesorId, int alumnoId, int cursoId, double notaFinal) throws ServiceException {
        try {
            daoProfesor.asignarNotaFinal(profesorId, alumnoId, cursoId, notaFinal);
        } catch (DAOException e) {
            throw new ServiceException("Error al asignar calificación final: " + e.getMessage());
        }
    }


//NO LO USO
    public void asignarCalificacion(int profesorId, int alumnoId, int cursoId, double nota) throws ServiceException {
        try {
            // Obtener la cantidad de notas parciales actuales
            int cantidadParciales = daoProfesor.obtenerCantidadNotasParciales(alumnoId, cursoId);

            // Si no se ha alcanzado el límite de parciales, asignar como parcial
            if (cantidadParciales < 3) { // Suponiendo que hay 3 notas parciales antes de la final
                daoProfesor.asignarNotaParcial(profesorId, alumnoId, cursoId, nota);
            } else {
                // Si es la última nota parcial, asignar la nota final
                daoProfesor.asignarNotaFinal(profesorId, alumnoId, cursoId, nota);
            }

        } catch (DAOException e) {
            throw new ServiceException("Error al asignar calificación: " + e.getMessage());
        }
    }
}

