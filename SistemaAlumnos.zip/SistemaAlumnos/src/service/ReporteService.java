package service;

import Controlador.Alumno;
import Controlador.Curso;
import Model.DAOCurso;
import Model.DAOException;

import java.util.List;

public class ReporteService {

    private CursoService cursoService;
    private DAOCurso daoCurso;
    public ReporteService() {
        cursoService = new CursoService();
        daoCurso = new DAOCurso();
    }

// Método para generar un reporte de recaudación de un curso
    public String generarReporteRecaudacion(Curso curso) throws ServiceException {
        try {
            int cantidadAlumnos = obtenerCantidadAlumnosPorCurso(curso.getId());
            double precioCurso = curso.getPrecio();
            double recaudacionTotal = cantidadAlumnos * precioCurso;

            return "Reporte del Curso: " + curso.getNombre() + "\n" +
                    "Cantidad de Alumnos Inscritos: " + cantidadAlumnos + "\n" +
                    "Precio por Alumno: $" + precioCurso + "\n" +
                    "Recaudación Total: $" + recaudacionTotal;
        } catch (Exception e) {
            throw new ServiceException("Error al generar el reporte de recaudación: " + e.getMessage());

        }
    }

    // Método para obtener cantidad de alumnos por curso
    private int obtenerCantidadAlumnosPorCurso(int cursoId) throws ServiceException {
        try {
            return daoCurso.obtenerCantidadAlumnosCurso(cursoId);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }
    }


}

