package service;

import Controlador.Administrador;
import Model.DAOAdministrador;
import Model.DAOException;

import java.util.ArrayList;

public class AdministradorService {
    private DAOAdministrador daoAdministrador;

    // Constructor que inicializa el DAOAdministrador
    public AdministradorService() {
        daoAdministrador = new DAOAdministrador();
    }

    // Método para guardar un administrador
    public void guardarAdministrador(Administrador administrador) throws ServiceException {
        try {
            daoAdministrador.guardar(administrador);
        } catch (DAOException e) {
            throw new ServiceException(e.getMessage());
        }
    }

    // Método para modificar un administrador
    public void modificarAdministrador(Administrador administrador) throws ServiceException {
        try {
            daoAdministrador.modificar(administrador);
        } catch (DAOException e) {
            throw new ServiceException(e.getMessage());
        }
    }

    // Método para eliminar un administrador por su ID
    public void eliminarAdministrador(int id) throws ServiceException {
        try {
            daoAdministrador.eliminar(id);
        } catch (DAOException e) {
            throw new ServiceException(e.getMessage());
        }
    }
    public Administrador buscar (int id) throws ServiceException{
        try{
            return daoAdministrador.buscar(id);
        }catch (DAOException d){
            throw new ServiceException(d.getMessage());
        }

    }

    public ArrayList<Administrador> buscarTodos() throws ServiceException {
        try{
            return daoAdministrador.buscarTodos();
        }catch (DAOException d){
            throw new ServiceException(d.getMessage());
        }
    }
}
