package service;
import Controlador.Administrador;
import Controlador.Curso;
import Model.DAOCurso;
import Model.DAOException;

import java.util.ArrayList;

public class CursoService {
    private DAOCurso daoCurso;

    // Constructor que inicializa el DAOCurso
    public CursoService() {
        daoCurso = new DAOCurso();
    }

    // Método para guardar un curso
    public void guardarCurso(Curso curso) throws ServiceException {
        try {
            daoCurso.guardar(curso);
        } catch (DAOException e) {
            throw new ServiceException(e.getMessage());
        }
    }

    // Método para modificar un curso
    public void modificarCurso(Curso curso) throws ServiceException {
        try {
            daoCurso.modificar(curso);
        } catch (DAOException e) {
            throw new ServiceException(e.getMessage());
        }
    }

    // Método para eliminar un curso por su ID
    public void eliminarCurso(int id) throws ServiceException {
        try {
            daoCurso.eliminar(id);
        } catch (DAOException e) {
            throw new ServiceException(e.getMessage());
        }
    }
    public Curso buscar (int id) throws ServiceException{
        try{
            return daoCurso.buscar(id);
        }catch (DAOException d){
            throw new ServiceException(d.getMessage());
        }

    }

    public ArrayList<Curso> buscarTodos() throws ServiceException {
        try{
            return daoCurso.buscarTodos();
        }catch (DAOException d){
            throw new ServiceException(d.getMessage());
        }
    }

}
